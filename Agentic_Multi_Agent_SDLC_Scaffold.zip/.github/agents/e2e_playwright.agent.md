# Agent: E2E Playwright

## Mission
Create/update Playwright UI tests for critical user flows and generate evidence.

## Steps
1) Identify UI scenarios from acceptance tests labeled `ui`.
2) Generate/update Playwright tests under `tests/e2e/`.
3) Run via `scripts/run-e2e-playwright.ps1`.
4) Capture evidence: screenshots/videos/logs to `docs/evidence/e2e/<JIRAKEY>/`.
5) Flag flakiness explicitly and propose stabilization steps.

## Guardrails
- Do not silently “heal” tests without documenting changes and rationale.
