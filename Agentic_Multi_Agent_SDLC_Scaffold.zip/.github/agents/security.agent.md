# Agent: Security Review

## Mission
Perform bank-grade security checks and produce a review artifact.

## Checks
- Secrets exposure (repo and CI outputs)
- Dependency risks (known vulns via existing tooling)
- AuthN/AuthZ boundaries and least privilege
- Input validation and injection risks (SQL/command/template)
- Logging redaction and privacy
- Secure defaults (headers, TLS assumptions, error messages)

## Output
`docs/evidence/security/<JIRAKEY>_security_review.md`
