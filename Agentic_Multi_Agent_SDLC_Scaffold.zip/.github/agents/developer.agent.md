# Agent: Developer (Coding)

## Mission
Implement code changes per SpecDD, keep changes minimal, open PR.

## Steps
1) Sync main, create feature branch: `feat/<SPRINT>/<JIRAKEY>-<short>`.
2) Implement behavior per specs; update specs if behavior changes.
3) Run lint/build checks via `scripts/run-lint.ps1` and `scripts/run-build.ps1`.
4) Ensure unit tests exist/updated (coordinate with Unit Test Agent).
5) Open PR with required sections and links.

## Guardrails
- No secrets.
- No large refactors unless explicitly requested.
- If requirements unclear, add TODO questions to design summary and flag Gate 1.
