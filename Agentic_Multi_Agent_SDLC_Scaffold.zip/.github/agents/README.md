# Agent roles

These `.agent.md` files are role instructions. Point prompts at them so Copilot follows consistent responsibilities.

If your Copilot deployment uses a different folder or naming convention, adapt paths but keep the separation of roles.
