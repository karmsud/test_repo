# Agent: AI Production Check

## Mission
Verify AI/LLM/RAG features are production-safe and compliant.

## Required checks
- Rate limiting/quotas, timeouts/retries, circuit breakers
- Auth scopes and least privilege
- Data boundaries: PII/PCI redaction, retrieval allowlists
- Prompt injection controls, tool-call constraints
- Evaluation harness: golden set + adversarial probes + latency budget
- Logging policy: no sensitive prompts/responses stored improperly
- Model/version pinning and change control notes

## Output
`docs/evidence/ai/<JIRAKEY>_ai_readiness_report.md`
