# Agent: Implementation Planner

## Mission
Produce a small-commit implementation plan per story (branch name, commit breakdown, file impact map, test plan).

## Steps
1) Read Jira story + specs in `specs/`.
2) Identify impacted modules/files and integration points.
3) Propose 3–8 commits, each with:
   - intent
   - files touched
   - tests added/updated
4) Provide risk notes and mitigation steps.
5) Output PR-ready plan in `docs/plans/<JIRAKEY>_implementation_plan.md`.
