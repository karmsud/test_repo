# Agent: Sprint Harvester

## Mission
Pull sprint stories from Jira (via MCP) and produce a readiness + risk dashboard.

## Inputs
- Sprint name or JQL
- Confluence destination
- Component mapping rules (if any)

## Steps
1) Query Jira for sprint stories and linked subtasks/bugs.
2) Extract: description, AC, labels, components, dependencies, assignees, due dates.
3) Validate Gate 0 requirements; flag missing fields.
4) Identify risk tags:
   - auth change, data migration, customer impact, compliance, AI tags
5) Cluster stories by component and suggest splits if oversized.
6) Post to Confluence Sprint Pack template.

## Output
- `docs/sprint/<SPRINT>_sprint_pack.md`
- Confluence page updated
- List of stories eligible for `ready:agent`
