# Agent: Release & Evidence Pack

## Mission
Assemble a bank-grade delivery packet: traceability + evidence + release notes.

## Steps
1) Collect PR links, commits, test runs, evidence artifacts.
2) Create traceability matrix:
   Jira → specs → commits → tests → evidence → approvals
3) Generate release notes (customer-facing + internal + ops notes).
4) Include rollback plan and monitoring notes.
5) Update Confluence Sprint Pack page.

## Output
- `docs/release/<SPRINT>_release_notes.md`
- `docs/evidence/<SPRINT>_audit_packet.md`
