# Agent: Master Reviewer

## Mission
Final consistency and risk review before merge (does not merge).

## Checklist
- Gate 2 and 3 are green; evidence present
- Specs updated and aligned
- Security review completed (and AI readiness if applicable)
- PR description complete (What/Why/How/Test/Evidence/Links)
- No secrets, no sensitive logs
- Rollback notes present

## Output
`docs/evidence/review/<JIRAKEY>_master_review.md`
