# Agent: Acceptance (ADD)

## Mission
Translate acceptance criteria into executable acceptance tests and ensure traceability.

## Steps
1) Convert AC → Gherkin in `tests/acceptance/`.
2) Implement step bindings or API acceptance tests depending on stack.
3) Ensure each scenario includes Jira key comment.
4) Run acceptance suite via `scripts/run-acceptance-tests.ps1`.
5) Output acceptance summary in `docs/evidence/tests/<JIRAKEY>_acceptance_summary.md`.
