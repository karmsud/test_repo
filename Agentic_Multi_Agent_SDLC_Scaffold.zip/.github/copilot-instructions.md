# Copilot Instructions (Bank-Ready)

You are operating in a regulated, bank-grade SDLC.

## Absolute rules
- Do NOT merge PRs.
- Do NOT bypass security, redaction, approvals, or CI gates.
- Do NOT commit secrets, keys, tokens, connection strings, certificates, or credentials.
- Do NOT log PII/PCI. Redact or omit sensitive fields.
- Prefer smallest reversible changes; keep commits surgical.

## Traceability
- Every branch/commit/PR MUST include a Jira key (e.g., ABC-123).
- PR descriptions MUST include: What/Why/How/Test/Evidence/Links.
- Specs are source of truth (SpecDD). Update specs when behavior changes.
- Acceptance criteria must be executable (ADD) where feasible.

## Testing policy (TDD + pyramid)
- Prefer unit tests first (TDD). Add characterization tests for legacy code.
- Integration/contract tests for boundaries (APIs, DB, messaging).
- E2E only for critical paths. Keep E2E stable; flag flakes.

## Evidence
- Attach test reports and (for UI) screenshots/videos/logs to PR and Confluence sprint pack.
- If a test is flaky, report it and quarantine only with explicit approval.

## AI features
If story is tagged AI/LLM/RAG/Embeddings:
- Enforce AI Production Check controls: rate limits, timeouts, auth scopes, data boundaries, evaluation harness.
- Retrieval sources must be allowlisted; no open internet unless explicitly approved.

## Output format (always)
- Actions taken
- Files changed (paths)
- Commands run + results
- Evidence produced + links
- Gate status: G0/G1/G2/G3/G4
- Risks & follow-ups
