## Jira
- Key: ABC-123
- Link:

## What
-

## Why
-

## How
-

## Tests
- Unit:
- Integration:
- Acceptance:
- E2E (Playwright):

## Evidence
- Reports:
- Screenshots/videos/logs:

## Spec alignment
- Spec files updated:
- Design summary updated:

## Risk & rollback
- Risk notes:
- Rollback plan:

## Gate status
- G0:
- G1:
- G2:
- G3:
- G4:
