# /plan_implementation

Use agent: `.github/agents/implementation_planner.agent.md`

For a given Jira key:
- Read story + spec files
- Produce a commit plan (3–8 commits)
- Impacted file map
- Risks + mitigations
- Test plan (unit/integration/acceptance/E2E)
