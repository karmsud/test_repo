# /implement_story

Use agent: `.github/agents/developer.agent.md`

For Jira key:
- Create branch `feat/<SPRINT>/<JIRAKEY>-<short>`
- Implement per SpecDD
- Keep changes minimal and reversible
- Open PR with required sections (What/Why/How/Test/Evidence/Links)
