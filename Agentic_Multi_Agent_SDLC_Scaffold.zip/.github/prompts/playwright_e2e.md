# /playwright_e2e

Use agent: `.github/agents/e2e_playwright.agent.md`

- Generate/update Playwright tests for acceptance scenarios marked `ui`
- Run Playwright via `scripts/run-e2e-playwright.ps1`
- Capture evidence (screenshots/videos/logs)
- Flag flakiness; do not silently heal without reporting changes
