# /tdd_unit_tests

Use agent: `.github/agents/unit_test.agent.md`

- Write failing unit tests first for the Jira story behaviors
- Ensure meaningful assertions + negative cases
- Run `scripts/run-unit-tests.ps1` and iterate until green
