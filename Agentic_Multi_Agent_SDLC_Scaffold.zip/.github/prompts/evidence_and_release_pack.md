# /evidence_and_release_pack

Use agent: `.github/agents/release_and_evidence.agent.md`

- Compile traceability matrix: Jira → commits → tests → evidence → approvals
- Generate release notes (customer-facing + internal)
- Include rollback and operational notes
- Update Confluence Sprint Pack page
