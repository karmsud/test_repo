# /security_review

Use agent: `.github/agents/security.agent.md`

- Secrets scan (repo + history if configured)
- Dependency risk review
- Auth boundaries and least privilege
- Logging redaction policy adherence
- OWASP top patterns relevant to stack

Output: `docs/evidence/security/<JIRAKEY>_security_review.md`
