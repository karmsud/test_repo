# /orchestrate_sprint

**Goal:** Orchestrate a sprint end-to-end using role-based agents (docs, dev, tests, security, release).

## Inputs
- Sprint name OR JQL:
- Repo:
- Confluence space/page:
- Environment for E2E (local/test):

## Instructions
1) Run **Sprint Harvester** to pull sprint stories and produce the sprint table + risk flags.
2) For stories meeting Gate 0, run **Specs Creator** to generate SpecDD + ADD artifacts.
3) For each story, run **Planner** to propose branch/commit breakdown.
4) For each story, run **Developer** + **Unit Test** agents until Gate 2 passes.
5) Run **Acceptance** + **E2E (Playwright)** until Gate 3 passes (capture evidence).
6) Run **Security Review** and (if AI-tagged) **AI Production Check**.
7) Run **Evidence & Release** pack.

## Output
- Confluence Sprint Pack page updated
- PR links per story
- Gate status dashboard
