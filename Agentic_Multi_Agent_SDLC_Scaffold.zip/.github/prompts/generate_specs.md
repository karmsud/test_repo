# /generate_specs

Use agent: `.github/agents/specs_creator.agent.md`

For each story labeled `ready:agent`:
- Generate SpecDD artifacts under `specs/`
- Generate ADD acceptance scenarios under `tests/acceptance/`
- Update Confluence design summary pages under `docs/templates/`

Commit to `spec/<SPRINT>/<JIRAKEY>` branches and open PRs (do not merge).
