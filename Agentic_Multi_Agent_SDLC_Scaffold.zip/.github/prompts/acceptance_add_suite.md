# /acceptance_add_suite

Use agent: `.github/agents/acceptance.agent.md`

- Convert AC → Gherkin feature(s)
- Implement steps (or API acceptance) as appropriate
- Ensure scenario ↔ Jira key traceability
- Run acceptance suite; report results
