# /master_review

Use agent: `.github/agents/master_reviewer.agent.md`

For Jira key:
- verify gates, evidence, security/AI artifacts
- ensure PR template complete
- output master review note to `docs/evidence/review/<JIRAKEY>_master_review.md`
