# /harvest_sprint

Use agent: `.github/agents/sprint_harvester.agent.md`

Query Jira via MCP for the sprint and produce:
- Story table (key, title, component, risk tags, readiness)
- Missing Gate 0 fields (AC, data tags, threat model, test intent, rollback)
- Suggested story splits
- Proposed AC and test intent for weak stories

Post results to Confluence using template in `docs/templates/confluence_sprint_pack_template.md`.
