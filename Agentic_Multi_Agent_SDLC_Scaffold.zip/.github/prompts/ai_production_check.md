# /ai_production_check

Use agent: `.github/agents/ai_production_check.agent.md`

For AI/LLM/RAG stories:
- Rate limits, timeouts, retries, circuit breakers
- Data boundaries & retrieval allowlist
- Prompt injection controls, tool-call constraints
- Eval harness: golden + adversarial tests + latency budget
- No secrets or sensitive logs

Output: `docs/evidence/ai/<JIRAKEY>_ai_readiness_report.md`
