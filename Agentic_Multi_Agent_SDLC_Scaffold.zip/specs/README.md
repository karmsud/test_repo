# specs/

Specs are the source of truth (SpecDD). Keep them structured and diffable.
