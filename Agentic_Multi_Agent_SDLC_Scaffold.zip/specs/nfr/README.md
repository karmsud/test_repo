# specs/nfr/

NFR specs: timeouts, retries, rate limits, logging/redaction, retention.
