Param(
  [string]$Path = "."
)

Write-Host "Run unit tests (placeholder). Customize for your stack."
Write-Host "Example:"
Write-Host "  npm test -- --runInBand"
Write-Host "  dotnet test"
Write-Host "  pytest -q"
exit 0
