Param(
  [string]$Path = "."
)

Write-Host "Run build (placeholder). Customize for your stack."
Write-Host "Example:"
Write-Host "  npm run build"
Write-Host "  dotnet build"
Write-Host "  python -m compileall ."
exit 0
