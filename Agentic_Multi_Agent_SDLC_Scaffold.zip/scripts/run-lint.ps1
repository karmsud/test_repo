Param(
  [string]$Path = "."
)

Write-Host "Run lint (placeholder). Customize for your stack."
Write-Host "Example:"
Write-Host "  npm run lint"
Write-Host "  dotnet format"
Write-Host "  python -m ruff check ."
exit 0
