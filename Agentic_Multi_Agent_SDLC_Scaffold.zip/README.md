# Agentic SDLC — Multi‑Agent Scaffold (Bank‑Ready)

**Date:** February 22, 2026  
**Purpose:** A practical, repo-ready scaffold for running a **multi-agent SDLC** using **GitHub Copilot in VS Code** plus **MCP servers** (Jira/Confluence/GitHub/Playwright).

This repo is **not** a runtime framework. It is:
- A **convention + file layout** that Copilot agents can reliably follow
- A **prompt pack** (slash commands) to run the workflow
- **Agent instruction files** that separate responsibilities (docs, coding, tests, security, AI checks, release)
- **Skills** files describing standard operating procedures (bank-grade gates)

If your org’s Copilot deployment supports:
- `.github/copilot-instructions.md`
- `.github/prompts/*.md` (slash commands)
- Agent instruction files (e.g., `.github/agents/*.agent.md` or equivalent)

…then this scaffold is immediately usable as a starting point.

---

## Quick start

1) Copy the contents of this scaffold into the target repository.
2) Confirm MCP connectivity in VS Code (Jira/Confluence/GitHub/Playwright as applicable).
3) Start with:  
   - `/harvest_sprint`  
   - `/generate_specs`  
   - `/implement_story`  
   - `/tdd_unit_tests`  
   - `/acceptance_add_suite`  
   - `/playwright_e2e`  
   - `/security_review`  
   - `/ai_production_check` (AI stories only)  
   - `/evidence_and_release_pack`

---

## What’s included

### GitHub Copilot configuration
- `.github/copilot-instructions.md` — global repo rules (security, traceability, gate discipline)
- `.github/prompts/*.md` — “slash command” prompt pack
- `.github/agents/*.agent.md` — role-based agent instructions (multi-agent separation)

### SpecDD + TDD + ADD structure
- `specs/` — source-of-truth specs (API, UI, NFR, rules)
- `tests/` — unit / integration / acceptance
- `docs/` — thin derived summaries + ADRs

### Skills (repeatable SOPs)
- `skills/` — skill playbooks used by agents (e.g., writing acceptance tests, producing evidence packs)

### Scripts
- `scripts/` — PowerShell-first helper scripts to run lint/tests/playwright consistently

---

## How multi-agent works (in practice)

Because Copilot’s exact orchestration features vary by enterprise config, this scaffold supports two approaches:

1) **Manual orchestration (recommended initially):** You run prompts in order; each prompt references the correct agent role file.
2) **Lead-orchestrator agent:** You run `/orchestrate_sprint`, and it delegates via explicit “hand-off sections” to other agents (still driven by you through prompt selection, unless your deployment supports true delegation).

See: `docs/workflow/agentic_sdlc_workflow.md`

---

## Safety defaults

- Agents **must not merge** PRs.
- Agents **must not** introduce secrets, reduce redaction, or bypass gates.
- All AI/RAG changes require the AI Production Check gate (policy-as-code recommended).

---

## Customize me

Start here:
- `docs/onboarding/customization_checklist.md`
- `docs/onboarding/mcp_tooling_contract.md`
