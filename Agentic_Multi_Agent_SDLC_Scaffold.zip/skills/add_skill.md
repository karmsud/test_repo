# Skill: ADD (Executable Acceptance)

## Goal
Make acceptance criteria executable and auditable.

## Rules
- Prefer Gherkin (Given/When/Then) or API acceptance tests.
- Maintain scenario ↔ Jira traceability.
- E2E only for critical paths; keep stable.

## Evidence
Produce `docs/evidence/tests/<JIRAKEY>_acceptance_summary.md` plus E2E artifacts when applicable.
