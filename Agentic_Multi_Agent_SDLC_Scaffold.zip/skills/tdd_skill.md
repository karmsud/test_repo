# Skill: TDD (Meaningful Unit Tests)

## Goal
Ensure correctness with fast, meaningful unit tests.

## Rules
- Write failing tests first where feasible.
- Include negative cases and boundary inputs.
- Avoid vacuous assertions; prove behavior changes.

## Evidence
Produce `docs/evidence/tests/<JIRAKEY>_unit_test_summary.md`.
