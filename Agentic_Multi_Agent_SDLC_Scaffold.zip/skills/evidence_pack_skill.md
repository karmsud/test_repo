# Skill: Evidence Pack (Audit Packet)

## Goal
Create an audit-friendly delivery packet for each sprint/release.

## Include
- Jira story list and status
- Links to specs and design summaries
- PRs/commits
- Test reports and evidence (screenshots/videos/logs)
- Security review artifacts
- AI readiness artifacts (if applicable)
- Rollback plan and operational notes
