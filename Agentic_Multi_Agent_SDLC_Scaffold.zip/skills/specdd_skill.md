# Skill: SpecDD (Structured Specs First)

## Goal
Create a diffable, enforceable spec that removes ambiguity for implementation and tests.

## Outputs
- API: OpenAPI + JSON Schema (when applicable)
- Rules: decision tables (YAML/JSON)
- NFR: timeouts/retries/rate limits/logging/redaction
- UI: flow + page model mapping
- Derived design summary (short)

## Rules
- Specs are the source of truth; prose is derived.
- If a requirement is unclear, record an OPEN QUESTION and do not guess silently.
