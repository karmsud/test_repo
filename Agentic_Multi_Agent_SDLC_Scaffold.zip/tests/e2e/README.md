# tests/e2e/

Playwright tests for critical UI paths.
