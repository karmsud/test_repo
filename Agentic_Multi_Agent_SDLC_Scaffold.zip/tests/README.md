# tests/

- unit/
- integration/
- acceptance/ (ADD)
- e2e/ (Playwright)
