# Customization Checklist (Bank/Org)

## Required
- Confirm your Copilot feature support for:
  - `.github/copilot-instructions.md`
  - `.github/prompts/*.md` slash commands
  - agent instruction files (`.github/agents/*.agent.md`)
- Confirm MCP servers and permissions:
  - Jira: read/write issues
  - Confluence: create/update pages
  - GitHub: branch/PR operations
  - Playwright: access to env and app

## Configure
- Branch naming conventions
- PR template conventions
- CI checks that map to Gate 2–4
- Where evidence artifacts are stored (repo vs external)
- Data classification policy mapping (PII/PCI/Internal/Public)
- AI governance policy (if AI features exist)

## Strongly recommended
- Standard templates for Jira and Confluence
- Golden acceptance tests for critical paths
- Secrets scanning and dependency scanning in CI
