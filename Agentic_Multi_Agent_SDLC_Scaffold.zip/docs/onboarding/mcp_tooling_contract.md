# MCP Tooling Contract (Assumptions)

This scaffold assumes MCP servers provide these high-level capabilities:

## Jira MCP
- Query sprint and issues (JQL)
- Read fields: description, AC, labels, components, links
- Update issues: labels, comments, fields (as permitted)

## Confluence MCP
- Create/update pages
- Append/replace sections
- Search pages by title

## GitHub MCP
- Pull repo content
- Create branch/commit
- Open PRs and update PR descriptions/comments

## Playwright MCP
- Launch browser against local/test env
- Run Playwright tests
- Collect screenshots/videos/logs

If any capability is missing, update prompts to match what’s available.
