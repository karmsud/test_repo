# docs/

Keep docs thin. Design summaries should be derived from specs.
Evidence artifacts live under docs/evidence/.
