# Agentic SDLC Workflow (Multi-Agent)

## The 5 gates
- G0: Story readiness (Jira)
- G1: Spec/design approval (specs + Confluence)
- G2: Build quality (PR checks)
- G3: Acceptance & evidence (CI + Playwright)
- G4: Governance & release readiness (security/AI/audit)

## Default flow (2-day candidate)
1) `/harvest_sprint` → sprint pack + readiness
2) Fix stories → label `ready:agent`
3) `/generate_specs` → SpecDD + ADD + design summaries
4) For each story:
   - `/plan_implementation`
   - `/tdd_unit_tests`
   - `/implement_story`
   - `/acceptance_add_suite`
   - `/playwright_e2e` (UI)
   - `/security_review`
   - `/ai_production_check` (AI)
5) `/evidence_and_release_pack`
6) `/master_review` (use master reviewer agent) and proceed with human merge approvals

## Notes
- “True delegation” varies by enterprise Copilot config. This scaffold works even when you manually run prompts.
