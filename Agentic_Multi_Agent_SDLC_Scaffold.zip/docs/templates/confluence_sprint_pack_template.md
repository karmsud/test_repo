# Confluence Sprint Pack Template (Markdown)

## Summary
- Sprint goal:
- Release window:
- Risk posture:

## Story Table
| Jira Key | Title | Component | Risk Tags | Gate Status | PR |
|---|---|---|---|---|---|

## Specs & Design
- Spec index (repo paths)
- Design summaries

## Tests & Evidence
- Unit tests
- Acceptance tests
- E2E evidence links

## Release Notes
- Customer-facing
- Internal
- Ops notes

## Rollback Plan
- Feature flags
- Deployment rollback
- Data rollback
