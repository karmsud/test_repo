"use client"

import type React from "react"

import { useRef, useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import { DollarSign, TrendingDown, CreditCard, Link2, Wallet, Receipt, MoreHorizontal } from "lucide-react"
import type { Node } from "@/components/waterfall-builder"
import { cn } from "@/lib/utils"

interface FlowNodeProps {
  node: Node
  isSelected: boolean
  isConnecting: boolean
  onSelect: () => void
  onDragStart: () => void
  onDragEnd: (x: number, y: number) => void
  onStartConnection: () => void
  onCompleteConnection: () => void
  canvasRef: React.RefObject<HTMLDivElement>
}

export function FlowNode({
  node,
  isSelected,
  isConnecting,
  onSelect,
  onDragStart,
  onDragEnd,
  onStartConnection,
  onCompleteConnection,
  canvasRef,
}: FlowNodeProps) {
  const nodeRef = useRef<HTMLDivElement>(null)
  const [isDragging, setIsDragging] = useState(false)
  const dragStartRef = useRef({ mouseX: 0, mouseY: 0, nodeX: 0, nodeY: 0 })

  const getNodeIcon = () => {
    switch (node.type) {
      case "available-fund":
        return <DollarSign className="h-5 w-5" />
      case "remaining-fund":
        return <Wallet className="h-5 w-5" />
      case "interest-payment":
        return <TrendingDown className="h-5 w-5" />
      case "principal-payment":
        return <CreditCard className="h-5 w-5" />
      case "fee-payment":
        return <Receipt className="h-5 w-5" />
      case "other-payment":
        return <MoreHorizontal className="h-5 w-5" />
    }
  }

  const getNodeColor = () => {
    switch (node.type) {
      case "available-fund":
        return "text-accent bg-accent/10 border-accent"
      case "remaining-fund":
        return "text-accent bg-accent/10 border-accent"
      case "interest-payment":
        return "text-chart-2 bg-chart-2/10 border-chart-2"
      case "principal-payment":
        return "text-chart-3 bg-chart-3/10 border-chart-3"
      case "fee-payment":
        return "text-chart-4 bg-chart-4/10 border-chart-4"
      case "other-payment":
        return "text-chart-5 bg-chart-5/10 border-chart-5"
    }
  }

  const getNodeTitle = () => {
    switch (node.type) {
      case "available-fund": return "Available Fund"
      case "remaining-fund": return "Remaining Fund"
      case "interest-payment": return "Interest Payment"
      case "principal-payment": return "Principal Payment"
      case "fee-payment": return "Fee Payment"
      case "other-payment": return "Other Payment"
    }
  }

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging && canvasRef.current) {
        const deltaX = e.clientX - dragStartRef.current.mouseX
        const deltaY = e.clientY - dragStartRef.current.mouseY

        const newX = dragStartRef.current.nodeX + deltaX
        const newY = dragStartRef.current.nodeY + deltaY

        const canvasRect = canvasRef.current.getBoundingClientRect()
        const constrainedX = Math.max(0, Math.min(newX, canvasRect.width - 240))
        const constrainedY = Math.max(0, Math.min(newY, canvasRect.height - 200))

        onDragEnd(constrainedX, constrainedY)
      }
    }

    const handleMouseUp = () => {
      if (isDragging) {
        setIsDragging(false)
      }
    }

    if (isDragging) {
      document.addEventListener("mousemove", handleMouseMove)
      document.addEventListener("mouseup", handleMouseUp)
    }

    return () => {
      document.removeEventListener("mousemove", handleMouseMove)
      document.removeEventListener("mouseup", handleMouseUp)
    }
  }, [isDragging, onDragEnd, canvasRef])

  const handleMouseDown = (e: React.MouseEvent) => {
    dragStartRef.current = {
      mouseX: e.clientX,
      mouseY: e.clientY,
      nodeX: node.x,
      nodeY: node.y,
    }
    setIsDragging(true)
    onDragStart()
    onSelect()
  }

  return (
    <div
      ref={nodeRef}
      className="absolute cursor-move"
      style={{
        left: `${node.x}px`,
        top: `${node.y}px`,
        width: "240px",
      }}
      onMouseDown={handleMouseDown}
    >
      <Card
        className={cn(
          "p-4 transition-all duration-200 hover:shadow-lg",
          isSelected && "ring-2 ring-ring shadow-xl",
          isConnecting && "ring-2 ring-accent animate-pulse",
        )}
      >
        <div className="flex items-start gap-3">
          <div className={cn("p-2 rounded-lg", getNodeColor())}>{getNodeIcon()}</div>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-sm text-card-foreground truncate">
              {getNodeTitle()}
            </h3>
            {node.label && <p className="text-xs text-muted-foreground mt-0.5 truncate">{node.label}</p>}
            <p className="text-lg font-bold text-foreground mt-1">${node.amount.toLocaleString()}</p>
            {node.payTo !== undefined && (
              <p className="text-xs text-muted-foreground mt-1">
                Pay To: <span className="font-medium text-foreground">{node.payTo || "Not set"}</span>
              </p>
            )}
          </div>
        </div>

        <div className="flex gap-2 mt-3">
          <button
            onClick={(e) => {
              e.stopPropagation()
              onStartConnection()
            }}
            className="flex-1 px-3 py-1.5 text-xs font-medium rounded-md bg-secondary hover:bg-secondary/80 text-secondary-foreground transition-colors"
          >
            <Link2 className="h-3 w-3 inline mr-1" />
            Connect
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation()
              onCompleteConnection()
            }}
            className="flex-1 px-3 py-1.5 text-xs font-medium rounded-md bg-accent hover:bg-accent/90 text-accent-foreground transition-colors"
          >
            Link Here
          </button>
        </div>
      </Card>
    </div>
  )
}
