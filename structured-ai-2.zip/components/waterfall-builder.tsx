"use client"

import type React from "react"

import { useState, useRef, useCallback, useEffect } from "react"
import { FlowNode } from "@/components/flow-node"
import { NodePanel } from "@/components/node-panel"
import { ConfigPanel } from "@/components/config-panel"
import { Button } from "@/components/ui/button"
import { ZoomIn, ZoomOut, Maximize2, RotateCcw } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export type NodeType = "available-fund" | "remaining-fund" | "interest-payment" | "principal-payment" | "fee-payment" | "other-payment"

export interface Node {
  id: string
  type: NodeType
  x: number
  y: number
  amount: number
  label: string
  connections: string[]
  payTo?: string
  due?: number
}

export interface Connection {
  from: string
  to: string
}

interface SavedState {
  nodes: Node[]
  connections: Connection[]
  zoom: number
  pan: { x: number; y: number }
}

const DEMO_NODES: Node[] = [
  {
    id: "demo-node-1",
    type: "available-fund",
    x: 340,
    y: 40,
    amount: 5250000,
    label: "Available Funds",
    connections: ["demo-node-2", "demo-node-3"],
  },
  {
    id: "demo-node-2",
    type: "fee-payment",
    x: 100,
    y: 240,
    amount: 15000,
    label: "Servicing Fee",
    connections: [],
    payTo: "AI Hackathon Servicing, LLC",
    due: 15000,
  },
  {
    id: "demo-node-3",
    type: "fee-payment",
    x: 580,
    y: 240,
    amount: 8500,
    label: "Trustee Fee",
    connections: ["demo-node-4"],
    payTo: "U.S. Bank National Association",
    due: 8500,
  },
  {
    id: "demo-node-4",
    type: "interest-payment",
    x: 340,
    y: 440,
    amount: 175000,
    label: "Class A Interest",
    connections: ["demo-node-5"],
    payTo: "Class A Noteholders",
    due: 175000,
  },
  {
    id: "demo-node-5",
    type: "interest-payment",
    x: 340,
    y: 640,
    amount: 62500,
    label: "Class B Interest",
    connections: ["demo-node-6"],
    payTo: "Class B Noteholders",
    due: 62500,
  },
  {
    id: "demo-node-6",
    type: "principal-payment",
    x: 340,
    y: 840,
    amount: 1200000,
    label: "Class A Principal",
    connections: ["demo-node-7"],
    payTo: "Class A Noteholders",
    due: 1200000,
  },
  {
    id: "demo-node-7",
    type: "other-payment",
    x: 340,
    y: 1040,
    amount: 26250,
    label: "Bond Insurance Premium",
    connections: ["demo-node-8"],
    payTo: "Bond Insurer",
    due: 26250,
  },
  {
    id: "demo-node-8",
    type: "remaining-fund",
    x: 340,
    y: 1240,
    amount: 3763250,
    label: "Remaining Funds",
    connections: [],
  },
]

const DEMO_CONNECTIONS: Connection[] = [
  { from: "demo-node-1", to: "demo-node-2" },
  { from: "demo-node-1", to: "demo-node-3" },
  { from: "demo-node-3", to: "demo-node-4" },
  { from: "demo-node-4", to: "demo-node-5" },
  { from: "demo-node-5", to: "demo-node-6" },
  { from: "demo-node-6", to: "demo-node-7" },
  { from: "demo-node-7", to: "demo-node-8" },
]

export function WaterfallBuilder() {
  const { toast } = useToast()
  const [nodes, setNodes] = useState<Node[]>(DEMO_NODES)
  const [connections, setConnections] = useState<Connection[]>(DEMO_CONNECTIONS)
  const [selectedNode, setSelectedNode] = useState<Node | null>(null)
  const [draggingNode, setDraggingNode] = useState<string | null>(null)
  const [connectingFrom, setConnectingFrom] = useState<string | null>(null)
  const [zoom, setZoom] = useState(1)
  const [pan, setPan] = useState({ x: 0, y: 0 })
  const [isPanning, setIsPanning] = useState(false)
  const [panStart, setPanStart] = useState({ x: 0, y: 0 })
  const canvasRef = useRef<HTMLDivElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const savedState = localStorage.getItem("waterfall-builder-state")
    if (savedState) {
      try {
        const parsed: SavedState = JSON.parse(savedState)
        setNodes(parsed.nodes)
        setConnections(parsed.connections)
        setZoom(parsed.zoom)
        setPan(parsed.pan)
      } catch (error) {
        setNodes(DEMO_NODES)
        setConnections(DEMO_CONNECTIONS)
      }
    }
  }, [])

  useEffect(() => {
    const stateToSave: SavedState = {
      nodes,
      connections,
      zoom,
      pan,
    }
    localStorage.setItem("waterfall-builder-state", JSON.stringify(stateToSave))
  }, [nodes, connections, zoom, pan])

  useEffect(() => {
    if (selectedNode) {
      const updatedNode = nodes.find((n) => n.id === selectedNode.id)
      if (updatedNode && JSON.stringify(updatedNode) !== JSON.stringify(selectedNode)) {
        setSelectedNode(updatedNode)
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nodes])

  const handleClearAll = useCallback(() => {
    if (confirm("Are you sure you want to reset to the demo layout? This cannot be undone.")) {
      setNodes(DEMO_NODES)
      setConnections(DEMO_CONNECTIONS)
      setSelectedNode(null)
      setZoom(1)
      setPan({ x: 0, y: 0 })
      localStorage.removeItem("waterfall-builder-state")
      toast({
        title: "Reset",
        description: "Waterfall has been restored to the demo layout.",
      })
    }
  }, [toast])

  const addNode = useCallback((type: NodeType) => {
    const isPaymentNode = type === "interest-payment" || type === "principal-payment" || type === "fee-payment" || type === "other-payment"
    const newNode: Node = {
      id: `node-${Date.now()}`,
      type,
      x: 100,
      y: 100,
      amount: !isPaymentNode ? 10000 : 0,
      label: "",
      connections: [],
      payTo: isPaymentNode ? "" : undefined,
      due: isPaymentNode ? 0 : undefined,
    }
    setNodes((prev) => [...prev, newNode])
  }, [])

  const updateNodePosition = useCallback((id: string, x: number, y: number) => {
    setNodes((prev) => prev.map((node) => (node.id === id ? { ...node, x, y } : node)))
  }, [])

  const updateNodeAmount = useCallback((id: string, amount: number) => {
    setNodes((prev) => prev.map((node) => (node.id === id ? { ...node, amount } : node)))
  }, [])

  const updateNodePayTo = useCallback((id: string, payTo: string) => {
    setNodes((prev) => prev.map((node) => (node.id === id ? { ...node, payTo } : node)))
  }, [])

  const updateNodeLabel = useCallback((id: string, label: string) => {
    setNodes((prev) => prev.map((node) => (node.id === id ? { ...node, label } : node)))
  }, [])

  const updateNodeDue = useCallback((id: string, due: number) => {
    setNodes((prev) => prev.map((node) => (node.id === id ? { ...node, due } : node)))
  }, [])

  const deleteNode = useCallback(
    (id: string) => {
      setNodes((prev) => prev.filter((node) => node.id !== id))
      setConnections((prev) => prev.filter((conn) => conn.from !== id && conn.to !== id))
      if (selectedNode?.id === id) {
        setSelectedNode(null)
      }
    },
    [selectedNode],
  )

  const startConnection = useCallback((nodeId: string) => {
    setConnectingFrom(nodeId)
  }, [])

  const completeConnection = useCallback(
    (toNodeId: string) => {
      if (connectingFrom && connectingFrom !== toNodeId) {
        setConnections((prev) => [...prev, { from: connectingFrom, to: toNodeId }])
        setNodes((prev) =>
          prev.map((node) =>
            node.id === connectingFrom ? { ...node, connections: [...node.connections, toNodeId] } : node,
          ),
        )
      }
      setConnectingFrom(null)
    },
    [connectingFrom],
  )

  const calculateAvailableFund = useCallback(() => {
    const availableFundNode = nodes.find((n) => n.type === "available-fund")
    if (!availableFundNode) return 0

    let total = availableFundNode.amount

    // Calculate deductions from connected payment nodes
    const processedNodes = new Set<string>()
    const queue = [availableFundNode.id]

    while (queue.length > 0) {
      const currentId = queue.shift()!
      if (processedNodes.has(currentId)) continue
      processedNodes.add(currentId)

      const currentNode = nodes.find((n) => n.id === currentId)
      if (!currentNode) continue

      currentNode.connections.forEach((connectedId) => {
        const connectedNode = nodes.find((n) => n.id === connectedId)
        if (
          connectedNode &&
          (connectedNode.type === "interest-payment" || connectedNode.type === "principal-payment")
        ) {
          total -= connectedNode.amount
          queue.push(connectedId)
        }
      })
    }

    return total
  }, [nodes])

  const handleZoomIn = useCallback(() => {
    setZoom((prev) => Math.min(prev + 0.1, 2))
  }, [])

  const handleZoomOut = useCallback(() => {
    setZoom((prev) => Math.max(prev - 0.1, 0.5))
  }, [])

  const handleResetZoom = useCallback(() => {
    setZoom(1)
    setPan({ x: 0, y: 0 })
  }, [])

  const handleMouseDown = useCallback(
    (e: React.MouseEvent) => {
      if (e.button === 1 || (e.button === 0 && e.shiftKey)) {
        // Middle mouse button or Shift + Left click
        setIsPanning(true)
        setPanStart({ x: e.clientX - pan.x, y: e.clientY - pan.y })
        e.preventDefault()
      }
    },
    [pan],
  )

  const handleMouseMove = useCallback(
    (e: React.MouseEvent) => {
      if (isPanning) {
        setPan({
          x: e.clientX - panStart.x,
          y: e.clientY - panStart.y,
        })
      }
    },
    [isPanning, panStart],
  )

  const handleMouseUp = useCallback(() => {
    setIsPanning(false)
  }, [])

  return (
    <div className="flex h-full bg-background">
      {/* Left Panel - Node Options */}
      <NodePanel onAddNode={addNode} />

      {/* Main Canvas */}
      <div className="flex-1 relative overflow-hidden">
        <div className="absolute top-4 left-4 z-10 flex items-center gap-2 bg-background/95 backdrop-blur-sm border rounded-lg p-2 shadow-lg">
          <Button size="sm" variant="outline" onClick={handleZoomOut} title="Zoom Out">
            <ZoomOut className="h-4 w-4" />
          </Button>
          <div className="px-3 py-1 text-sm font-medium min-w-[60px] text-center">{Math.round(zoom * 100)}%</div>
          <Button size="sm" variant="outline" onClick={handleZoomIn} title="Zoom In">
            <ZoomIn className="h-4 w-4" />
          </Button>
          <div className="w-px h-6 bg-border" />
          <Button size="sm" variant="outline" onClick={handleResetZoom} title="Reset View">
            <Maximize2 className="h-4 w-4" />
          </Button>
          <div className="w-px h-6 bg-border" />
          <Button size="sm" variant="outline" onClick={handleClearAll} title="Clear All Nodes">
            <RotateCcw className="h-4 w-4" />
          </Button>
        </div>

        <div
          ref={containerRef}
          className="w-full h-full overflow-auto"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          style={{ cursor: isPanning ? "grabbing" : "default" }}
        >
          <div
            ref={canvasRef}
            className="bg-muted/30 relative"
            style={{
              width: "4000px",
              height: "3000px",
              backgroundImage: `
                linear-gradient(to right, oklch(var(--border) / 0.3) 1px, transparent 1px),
                linear-gradient(to bottom, oklch(var(--border) / 0.3) 1px, transparent 1px)
              `,
              backgroundSize: `${24 * zoom}px ${24 * zoom}px`,
              transform: `scale(${zoom})`,
              transformOrigin: "0 0",
            }}
          >
            {/* Connection Lines */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none">
              <defs>
                <marker
                  id="arrowhead"
                  markerWidth="10"
                  markerHeight="10"
                  refX="9"
                  refY="3"
                  orient="auto"
                  className="fill-blue-500"
                >
                  <polygon points="0 0, 10 3, 0 6" fill="currentColor" />
                </marker>
              </defs>
              {connections.map((conn, idx) => {
                const fromNode = nodes.find((n) => n.id === conn.from)
                const toNode = nodes.find((n) => n.id === conn.to)
                if (!fromNode || !toNode) return null

                const x1 = fromNode.x + 120
                const y1 = fromNode.y + 80
                const x2 = toNode.x + 120
                const y2 = toNode.y

                const midY = (y1 + y2) / 2
                const path = `M ${x1} ${y1} C ${x1} ${midY}, ${x2} ${midY}, ${x2} ${y2}`

                return (
                  <g key={idx}>
                    <path
                      d={path}
                      stroke="#3b82f6"
                      strokeWidth="2"
                      strokeDasharray="8,4"
                      fill="none"
                      markerEnd="url(#arrowhead)"
                      opacity="0.8"
                    />
                  </g>
                )
              })}
            </svg>

            {/* Nodes */}
            {nodes.map((node) => (
              <FlowNode
                key={node.id}
                node={node}
                isSelected={selectedNode?.id === node.id}
                isConnecting={connectingFrom === node.id}
                onSelect={() => setSelectedNode(node)}
                onDragStart={() => setDraggingNode(node.id)}
                onDragEnd={(x, y) => {
                  updateNodePosition(node.id, x, y)
                  setDraggingNode(null)
                }}
                onStartConnection={() => startConnection(node.id)}
                onCompleteConnection={() => completeConnection(node.id)}
                canvasRef={canvasRef}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Right Panel - Configuration */}
      <ConfigPanel
        selectedNode={selectedNode}
        onUpdateAmount={updateNodeAmount}
        onUpdatePayTo={updateNodePayTo}
        onUpdateLabel={updateNodeLabel}
        onUpdateDue={updateNodeDue}
        onDeleteNode={deleteNode}
      />
    </div>
  )
}
