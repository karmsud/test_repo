"use client"

import { useState, useRef, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Sparkles, X, Send, Bot } from "lucide-react"
import { cn } from "@/lib/utils"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

interface AIChatPanelProps {
  isOpen: boolean
  onClose: () => void
}

const WELCOME_MESSAGE: Message = {
  id: "welcome",
  role: "assistant",
  content: "Hi! I'm your StructuredAI Agent. I can help you with your structured finance modeling setup — field mappings, data validation, deal configuration, and more. Ask me anything!",
  timestamp: new Date(),
}

const QUICK_ACTIONS = [
  "What fields are still unmapped?",
  "Explain ARM rate fields",
  "Validate my data mappings",
  "Help me configure deal waterfall",
]

const MOCK_RESPONSES: Record<string, string> = {
  "unmapped": "Based on your current mapping progress, you have 5 unmapped required fields: Months to Maturity, First Reset Date, Original Term, Subsequent Period Rate Change Cap, and Subsequent Period Rate Change Floor. Would you like me to suggest source field matches?",
  "arm": "ARM (Adjustable Rate Mortgage) fields define how the interest rate adjusts over time. Key fields include:\n\n• **ARM Index** — the benchmark rate (e.g., SOFR, Prime)\n• **ARM Margin** — spread added to the index\n• **Lifetime Rate Cap/Floor** — absolute rate bounds\n• **Rate Reset Frequency** — how often the rate adjusts\n\nAll ARM fields are required when the Adjustable Rate Flag is set to 'Y'.",
  "validate": "I've analyzed your current data mappings. Here's the validation summary:\n\n✓ 42 fields successfully mapped\n✓ Data types match for all mapped fields\n⚠ 5 required fields still need mapping\n⚠ 2 fields have potential type mismatches\n\nWould you like me to show details on the fields that need attention?",
  "waterfall": "I can help you configure your deal waterfall. The waterfall defines the priority of payments from available funds. Common structures include:\n\n1. **Senior/Subordinate** — Senior tranches paid first\n2. **Sequential Pay** — Each tranche paid in order\n3. **Pro Rata** — Proportional payments across tranches\n\nWhich structure would you like to set up, or would you like me to analyze your current configuration?",
  "compare": "Deal 2022-ABS1 appears to be similar to your current deal. However, your current deal structure includes additional waterfall rules for paying bond insurance premiums and allocating loss recoveries from the insurance fund. Would you like me to check whether your waterfall rules include these provisions?",
  "default": "That's a great question! In a production environment, I'd query your deal model and data mappings to give you a precise answer. This feature is coming soon — stay tuned!",
}

function getAIResponse(userMessage: string): string {
  const lowerMessage = userMessage.toLowerCase()
  
  if (lowerMessage.includes("unmapped") || lowerMessage.includes("still need")) {
    return MOCK_RESPONSES.unmapped
  }
  if (lowerMessage.includes("arm") || lowerMessage.includes("adjustable")) {
    return MOCK_RESPONSES.arm
  }
  if (lowerMessage.includes("validate") || lowerMessage.includes("validation")) {
    return MOCK_RESPONSES.validate
  }
  if (lowerMessage.includes("waterfall") || lowerMessage.includes("configure")) {
    return MOCK_RESPONSES.waterfall
  }
  if (lowerMessage.includes("compare") || lowerMessage.includes("shelf") || lowerMessage.includes("other deal") || lowerMessage.includes("attention")) {
    return MOCK_RESPONSES.compare
  }
  return MOCK_RESPONSES.default
}

function formatTime(date: Date): string {
  return date.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })
}

export function AIChatPanel({ isOpen, onClose }: AIChatPanelProps) {
  const [messages, setMessages] = useState<Message[]>([WELCOME_MESSAGE])
  const [inputValue, setInputValue] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const [showQuickActions, setShowQuickActions] = useState(true)
  const scrollAreaRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const scrollToBottom = useCallback(() => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current.querySelector("[data-radix-scroll-area-viewport]")
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight
      }
    }
  }, [])

  useEffect(() => {
    scrollToBottom()
  }, [messages, isTyping, scrollToBottom])

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus()
    }
  }, [isOpen])

  const sendMessage = useCallback((content: string) => {
    if (!content.trim()) return

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      role: "user",
      content: content.trim(),
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputValue("")
    setShowQuickActions(false)
    setIsTyping(true)

    // Simulate AI thinking delay
    setTimeout(() => {
      const aiResponse: Message = {
        id: `ai-${Date.now()}`,
        role: "assistant",
        content: getAIResponse(content),
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, aiResponse])
      setIsTyping(false)
    }, 3000)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    sendMessage(inputValue)
  }

  const handleQuickAction = (action: string) => {
    sendMessage(action)
  }

  return (
    <>
      {/* Panel - no backdrop, main app remains accessible */}
      <div
        className={cn(
          "fixed top-0 right-0 z-50 h-full w-[420px] bg-card border-l shadow-2xl transition-transform duration-300 ease-out flex flex-col",
          isOpen ? "translate-x-0" : "translate-x-full"
        )}
      >
        {/* Header */}
        <div className="shrink-0 bg-gradient-to-r from-primary to-primary/80 px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/20">
                <Sparkles className="h-5 w-5 text-primary-foreground" />
              </div>
              <div>
                <h2 className="font-semibold text-primary-foreground">StructuredAI Agent</h2>
                <p className="text-xs text-primary-foreground/80">Your structured finance modeling assistant</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="h-8 w-8 text-primary-foreground hover:bg-white/20 hover:text-primary-foreground"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Messages */}
        <ScrollArea ref={scrollAreaRef} className="flex-1 p-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={cn(
                  "flex gap-3",
                  message.role === "user" ? "justify-end" : "justify-start"
                )}
              >
                {message.role === "assistant" && (
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10">
                    <Bot className="h-4 w-4 text-primary" />
                  </div>
                )}
                  <div
                    className={cn(
                      "max-w-xs rounded-2xl px-4 py-2.5",
                      message.role === "user"
                        ? "bg-primary text-primary-foreground rounded-br-md"
                        : "bg-muted text-foreground rounded-bl-md"
                    )}
                  >
                  <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                  <p
                    className={cn(
                      "mt-1 text-[10px]",
                      message.role === "user" ? "text-primary-foreground/70" : "text-muted-foreground"
                    )}
                  >
                    {formatTime(message.timestamp)}
                  </p>
                </div>
              </div>
            ))}

            {/* Typing indicator */}
            {isTyping && (
              <div className="flex gap-3 justify-start">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10">
                  <Bot className="h-4 w-4 text-primary" />
                </div>
                <div className="bg-muted rounded-2xl rounded-bl-md px-4 py-3">
                  <div className="flex gap-1">
                    <span className="h-2 w-2 rounded-full bg-muted-foreground/50 animate-bounce [animation-delay:0ms]" />
                    <span className="h-2 w-2 rounded-full bg-muted-foreground/50 animate-bounce [animation-delay:150ms]" />
                    <span className="h-2 w-2 rounded-full bg-muted-foreground/50 animate-bounce [animation-delay:300ms]" />
                  </div>
                </div>
              </div>
            )}

            {/* Quick Actions */}
            {showQuickActions && messages.length === 1 && (
              <div className="pt-2">
                <p className="text-xs text-muted-foreground mb-2">Quick actions:</p>
                <div className="flex flex-wrap gap-2">
                  {QUICK_ACTIONS.map((action) => (
                    <button
                      key={action}
                      onClick={() => handleQuickAction(action)}
                      className="text-xs px-3 py-1.5 rounded-full border border-primary/30 text-primary hover:bg-primary/10 transition-colors"
                    >
                      {action}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Input */}
        <div className="shrink-0 border-t p-4">
          <form onSubmit={handleSubmit} className="flex gap-2">
            <textarea
              ref={inputRef as any}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Ask about your model setup..."
              className="flex-1 min-h-[80px] p-2.5 rounded-md border border-input bg-background text-sm placeholder:text-muted-foreground resize-none"
              disabled={isTyping}
            />
            <Button type="submit" size="icon" disabled={!inputValue.trim() || isTyping} className="self-end">
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </div>
      </div>
    </>
  )
}

export function AIChatButton({ onClick }: { onClick: () => void }) {
  return (
    <Button
      onClick={onClick}
      className="gap-2 bg-yellow-400 text-black hover:bg-yellow-500"
    >
      <Sparkles className="h-4 w-4" />
      <span className="hidden sm:inline">StructuredAI Agent</span>
    </Button>
  )
}
