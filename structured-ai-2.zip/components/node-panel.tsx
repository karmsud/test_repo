"use client"

import { Card } from "@/components/ui/card"
import { DollarSign, TrendingDown, CreditCard, Wallet, Receipt, MoreHorizontal } from "lucide-react"
import type { NodeType } from "@/components/waterfall-builder"

interface NodePanelProps {
  onAddNode: (type: NodeType) => void
}

export function NodePanel({ onAddNode }: NodePanelProps) {
  return (
    <div className="w-64 bg-sidebar border-r border-sidebar-border p-4 flex flex-col gap-4 h-full">
      <div className="mb-2 shrink-0">
        <h2 className="text-lg font-semibold text-sidebar-foreground">Waterfall Builder</h2>
        <p className="text-sm text-muted-foreground">Add nodes to canvas</p>
      </div>

      <div className="flex flex-col gap-3 overflow-y-auto flex-1 pr-1">
        <Card
          className="p-4 hover:shadow-md transition-shadow cursor-pointer border-2 border-transparent hover:border-accent shrink-0"
          onClick={() => onAddNode("available-fund")}
        >
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-accent/10">
              <DollarSign className="h-5 w-5 text-accent" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-sm text-card-foreground">Available Fund</h3>
              <p className="text-xs text-muted-foreground mt-1">Starting capital amount</p>
            </div>
          </div>
        </Card>

        <Card
          className="p-4 hover:shadow-md transition-shadow cursor-pointer border-2 border-transparent hover:border-chart-2 shrink-0"
          onClick={() => onAddNode("interest-payment")}
        >
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-chart-2/10">
              <TrendingDown className="h-5 w-5 text-chart-2" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-sm text-card-foreground">Interest Payment</h3>
              <p className="text-xs text-muted-foreground mt-1">Deduct interest amount</p>
            </div>
          </div>
        </Card>

        <Card
          className="p-4 hover:shadow-md transition-shadow cursor-pointer border-2 border-transparent hover:border-chart-3 shrink-0"
          onClick={() => onAddNode("principal-payment")}
        >
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-chart-3/10">
              <CreditCard className="h-5 w-5 text-chart-3" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-sm text-card-foreground">Principal Payment</h3>
              <p className="text-xs text-muted-foreground mt-1">Deduct principal amount</p>
            </div>
          </div>
        </Card>

        <Card
          className="p-4 hover:shadow-md transition-shadow cursor-pointer border-2 border-transparent hover:border-chart-4 shrink-0"
          onClick={() => onAddNode("fee-payment")}
        >
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-chart-4/10">
              <Receipt className="h-5 w-5 text-chart-4" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-sm text-card-foreground">Fee Payment</h3>
              <p className="text-xs text-muted-foreground mt-1">Deduct fee amount</p>
            </div>
          </div>
        </Card>

        <Card
          className="p-4 hover:shadow-md transition-shadow cursor-pointer border-2 border-transparent hover:border-chart-5 shrink-0"
          onClick={() => onAddNode("other-payment")}
        >
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-chart-5/10">
              <MoreHorizontal className="h-5 w-5 text-chart-5" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-sm text-card-foreground">Other Payment</h3>
              <p className="text-xs text-muted-foreground mt-1">Miscellaneous deduction</p>
            </div>
          </div>
        </Card>

        <Card
          className="p-4 hover:shadow-md transition-shadow cursor-pointer border-2 border-transparent hover:border-accent shrink-0"
          onClick={() => onAddNode("remaining-fund")}
        >
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-accent/10">
              <Wallet className="h-5 w-5 text-accent" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-sm text-card-foreground">Remaining Fund</h3>
              <p className="text-xs text-muted-foreground mt-1">Remaining capital amount</p>
            </div>
          </div>
        </Card>
      </div>

      <div className="shrink-0 pt-4 border-t border-sidebar-border">
        <p className="text-xs text-muted-foreground">
          Click nodes to add them to the canvas. Drag to position and connect nodes to create your waterfall model.
        </p>
      </div>
    </div>
  )
}
