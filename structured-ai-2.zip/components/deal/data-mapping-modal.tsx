"use client"

import { useState, useCallback } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Search, X, ChevronDown, GripVertical, CheckCircle2, AlertCircle } from "lucide-react"
import { cn } from "@/lib/utils"

interface DataMappingModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  mapName: string
}

interface SourceField {
  id: string
  name: string
  mapped: boolean
  mappedTo?: string
}

interface RequiredField {
  id: string
  name: string
  category: string
  mappedFrom?: string
  required: boolean
}

const initialSourceFields: SourceField[] = [
  { id: "sf1",  name: "Loan Number",                      mapped: true,  mappedTo: "rf1"  },
  { id: "sf2",  name: "UPB",                              mapped: true,  mappedTo: "rf2"  },
  { id: "sf3",  name: "Note Rate",                        mapped: true,  mappedTo: "rf3"  },
  { id: "sf4",  name: "Age",                              mapped: true,  mappedTo: "rf4"  },
  { id: "sf5",  name: "Orig Term",                        mapped: false },
  { id: "sf6",  name: "Paid To Dt",                       mapped: false },
  { id: "sf7",  name: "Scheduled Maturity Dt",            mapped: false },
  { id: "sf8",  name: "ARM - Initial Period Rate Change",  mapped: false },
  { id: "sf9",  name: "ARM - Lifetime Rate Cap",           mapped: false },
  { id: "sf10", name: "ARM - Lifetime Rate Floor",         mapped: false },
  { id: "sf11", name: "ARM - Margin",                      mapped: false },
  { id: "sf12", name: "ARM - Payment Reset Frequency",     mapped: false },
  { id: "sf13", name: "ARM - Rate Reset Frequency",        mapped: false },
  { id: "sf14", name: "ARM - Subsequent Period Rate",      mapped: false },
  { id: "sf15", name: "First Payment Dt",                  mapped: false },
  { id: "sf16", name: "Next Payment Dt",                   mapped: false },
  { id: "sf17", name: "Combined Orig LTV",                 mapped: false },
  { id: "sf18", name: "Orig Appraisal Value",              mapped: false },
  { id: "sf19", name: "Original FICO",                     mapped: false },
  { id: "sf20", name: "Original LTV",                      mapped: false },
  { id: "sf21", name: "Original Principal Balance",        mapped: false },
  { id: "sf22", name: "Amortization Type",                 mapped: false },
  { id: "sf23", name: "Interest Only Period",              mapped: false },
  { id: "sf24", name: "Current Balance",                   mapped: false },
  { id: "sf25", name: "Months to Maturity",                mapped: false },
]

const initialRequiredFields: RequiredField[] = [
  { id: "rf1",  name: "Unique Identifier",              category: "Current Characteristics",     mappedFrom: "sf1",  required: true  },
  { id: "rf2",  name: "Ending UPB Amount",              category: "Current Characteristics",     mappedFrom: "sf2",  required: true  },
  { id: "rf3",  name: "Net Note Rate",                  category: "Current Characteristics",     mappedFrom: "sf3",  required: true  },
  { id: "rf4",  name: "Loan Age",                       category: "Current Characteristics",     mappedFrom: "sf4",  required: true  },
  { id: "rf5",  name: "Paid To Date",                   category: "Current Characteristics",     required: true  },
  { id: "rf6",  name: "Current Balance",                category: "Current Characteristics",     required: true  },
  { id: "rf7",  name: "Current Note Rate",              category: "Current Characteristics",     required: false },
  { id: "rf8",  name: "Months to Maturity",             category: "Current Characteristics",     required: false },
  { id: "rf9",  name: "Adjustable Rate Flag",           category: "Adjustable Rate Fields",      required: true  },
  { id: "rf10", name: "ARM Index",                      category: "Adjustable Rate Fields",      required: true  },
  { id: "rf11", name: "ARM Margin",                     category: "Adjustable Rate Fields",      required: true  },
  { id: "rf12", name: "Rate Reset Frequency",           category: "Adjustable Rate Fields",      required: false },
  { id: "rf13", name: "Initial Period Rate Change Cap", category: "Adjustable Rate Fields",      required: false },
  { id: "rf14", name: "Lifetime Rate Cap",              category: "Adjustable Rate Fields",      required: false },
  { id: "rf15", name: "Lifetime Rate Floor",            category: "Adjustable Rate Fields",      required: false },
  { id: "rf16", name: "Payment Reset Frequency",        category: "Adjustable Rate Fields",      required: false },
  { id: "rf17", name: "Origination Date",               category: "Original Characteristics",    required: true  },
  { id: "rf18", name: "Original Term",                  category: "Original Characteristics",    required: true  },
  { id: "rf19", name: "Original FICO",                  category: "Original Characteristics",    required: false },
  { id: "rf20", name: "Original LTV",                   category: "Original Characteristics",    required: false },
  { id: "rf21", name: "Original Principal Balance",     category: "Original Characteristics",    required: true  },
  { id: "rf22", name: "Amortization Type",              category: "Original Characteristics",    required: false },
  { id: "rf23", name: "Scheduled Maturity Date",        category: "Original Characteristics",    required: false },
  { id: "rf24", name: "Combined Original LTV",          category: "Original Characteristics",    required: false },
  { id: "rf25", name: "Original Appraisal Value",       category: "Original Characteristics",    required: false },
  { id: "rf26", name: "First Payment Date",             category: "Performance Characteristics", required: false },
  { id: "rf27", name: "Months to Next Payment Reset",   category: "Performance Characteristics", required: false },
  { id: "rf28", name: "Paid To Date",                   category: "Performance Characteristics", required: false },
]

const CATEGORIES = [
  "Current Characteristics",
  "Adjustable Rate Fields",
  "Original Characteristics",
  "Performance Characteristics",
]

export function DataMappingModal({ open, onOpenChange, mapName }: DataMappingModalProps) {
  const [sourceFields, setSourceFields]             = useState<SourceField[]>(initialSourceFields)
  const [requiredFields, setRequiredFields]         = useState<RequiredField[]>(initialRequiredFields)
  const [searchTerm, setSearchTerm]                 = useState("")
  const [draggedField, setDraggedField]             = useState<SourceField | null>(null)
  const [expandedCategories, setExpandedCategories] = useState<string[]>(CATEGORIES)
  const [dragOverTarget, setDragOverTarget]         = useState<string | null>(null)

  const mappedCount  = requiredFields.filter((f) => f.mappedFrom).length
  const totalCount   = requiredFields.length
  const unmappedReqd = requiredFields.filter((f) => f.required && !f.mappedFrom).length

  const filteredSource = sourceFields.filter((f) =>
    f.name.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const toggleCategory = (cat: string) =>
    setExpandedCategories((prev) =>
      prev.includes(cat) ? prev.filter((c) => c !== cat) : [...prev, cat]
    )

  const handleDragStart = useCallback((field: SourceField) => {
    if (!field.mapped) setDraggedField(field)
  }, [])

  const handleDragEnd = useCallback(() => {
    setDraggedField(null)
    setDragOverTarget(null)
  }, [])

  const handleDrop = useCallback(
    (requiredFieldId: string) => {
      if (!draggedField) return
      setSourceFields((prev) =>
        prev.map((f) =>
          f.id === draggedField.id ? { ...f, mapped: true, mappedTo: requiredFieldId } : f
        )
      )
      setRequiredFields((prev) =>
        prev.map((f) =>
          f.id === requiredFieldId ? { ...f, mappedFrom: draggedField.id } : f
        )
      )
      setDraggedField(null)
      setDragOverTarget(null)
    },
    [draggedField]
  )

  const handleRemoveMapping = useCallback(
    (requiredFieldId: string) => {
      const rf = requiredFields.find((f) => f.id === requiredFieldId)
      if (!rf?.mappedFrom) return
      setSourceFields((prev) =>
        prev.map((f) =>
          f.id === rf.mappedFrom ? { ...f, mapped: false, mappedTo: undefined } : f
        )
      )
      setRequiredFields((prev) =>
        prev.map((f) =>
          f.id === requiredFieldId ? { ...f, mappedFrom: undefined } : f
        )
      )
    },
    [requiredFields]
  )

  const getSourceName = (id: string) =>
    sourceFields.find((f) => f.id === id)?.name ?? ""

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="flex flex-col p-0 gap-0 overflow-hidden rounded-xl"
        style={{ maxWidth: "70vw", width: "70vw", height: "86vh", maxHeight: "86vh" }}
      >
        {/* Header */}
        <DialogHeader className="shrink-0 px-6 py-4 border-b bg-card">
          <div className="flex items-start justify-between gap-4">
            <div>
              <DialogTitle className="text-lg font-semibold leading-tight">
                Data Map: {mapName}
              </DialogTitle>
              <p className="text-sm text-muted-foreground mt-1">
                Drag source fields onto the required model fields to create mappings
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0 pt-0.5">
              {unmappedReqd > 0 && (
                <Badge
                  variant="outline"
                  className="gap-1.5 bg-destructive/10 text-destructive border-destructive/30"
                >
                  <AlertCircle className="h-3 w-3" />
                  {unmappedReqd} required unmapped
                </Badge>
              )}
              <Badge
                variant="outline"
                className="gap-1.5 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/30"
              >
                <CheckCircle2 className="h-3 w-3" />
                {mappedCount} / {totalCount} mapped
              </Badge>
            </div>
          </div>
        </DialogHeader>

        {/* Column headers */}
        <div className="shrink-0 grid grid-cols-[260px_1fr_1fr] border-b bg-muted/50">
          <div className="px-4 py-2.5 border-r border-border">
            <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Source Data Fields
            </span>
          </div>
          <div className="px-4 py-2.5 border-r border-border">
            <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Required Model Field
            </span>
          </div>
          <div className="px-4 py-2.5">
            <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Mapped Source Field
            </span>
          </div>
        </div>

        {/* Body — all three columns side by side, each independently scrollable */}
        <div className="flex flex-1 min-h-0 overflow-hidden">

          {/* ── Column 1: Source Data Fields (independently scrollable) ── */}
          <div className="w-[260px] shrink-0 border-r border-border flex flex-col bg-background">
            {/* Sticky search within this column */}
            <div className="shrink-0 px-3 py-3 border-b border-border bg-background">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground pointer-events-none" />
                <Input
                  placeholder="Search fields..."
                  className="pl-8 h-8 text-sm bg-muted/50"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            {/* Scrollable field list */}
            <div className="flex-1 overflow-y-auto min-h-0 p-2 space-y-1">
              {filteredSource.map((field) => (
                <div
                  key={field.id}
                  draggable={!field.mapped}
                  onDragStart={() => handleDragStart(field)}
                  onDragEnd={handleDragEnd}
                  className={cn(
                    "flex items-center gap-2 px-3 py-2 rounded-md border text-sm select-none transition-all duration-150",
                    field.mapped
                      ? "bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800/60 opacity-75"
                      : "bg-card border-border hover:border-primary/40 hover:shadow-sm cursor-grab active:cursor-grabbing active:shadow-md active:opacity-60",
                    draggedField?.id === field.id && "opacity-30 scale-95"
                  )}
                >
                  {field.mapped ? (
                    <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500 shrink-0" />
                  ) : (
                    <GripVertical className="h-3.5 w-3.5 text-muted-foreground/40 shrink-0" />
                  )}
                  <span
                    className={cn(
                      "flex-1 truncate leading-tight text-xs",
                      field.mapped
                        ? "text-emerald-700 dark:text-emerald-400"
                        : "text-foreground"
                    )}
                  >
                    {field.name}
                  </span>
                  {field.mapped && (
                    <span className="text-[9px] font-semibold uppercase tracking-wide text-emerald-600 dark:text-emerald-400 shrink-0">
                      Mapped
                    </span>
                  )}
                </div>
              ))}
              {filteredSource.length === 0 && (
                <div className="px-3 py-6 text-center text-xs text-muted-foreground">
                  No fields match your search
                </div>
              )}
            </div>
          </div>

          {/* ── Columns 2 + 3: Required fields & drop zones (independently scrollable) ── */}
          <div className="flex-1 overflow-y-auto min-h-0">
            <div className="p-3 space-y-2">
              {CATEGORIES.map((category) => {
                const fields    = requiredFields.filter((f) => f.category === category)
                const isOpen    = expandedCategories.includes(category)
                const catMapped = fields.filter((f) => f.mappedFrom).length

                return (
                  <div key={category} className="rounded-lg border border-border bg-card overflow-hidden">
                    {/* Category header */}
                    <button
                      onClick={() => toggleCategory(category)}
                      className="w-full flex items-center gap-2.5 px-4 py-2.5 bg-muted/40 hover:bg-muted/70 transition-colors text-left"
                    >
                      <ChevronDown
                        className={cn(
                          "h-4 w-4 text-muted-foreground transition-transform duration-200 shrink-0",
                          !isOpen && "-rotate-90"
                        )}
                      />
                      <span className="font-medium text-sm flex-1 text-foreground">{category}</span>
                      <span className="text-xs text-muted-foreground">
                        {catMapped}/{fields.length}
                      </span>
                      <div className="h-1.5 w-16 rounded-full bg-border overflow-hidden ml-1">
                        <div
                          className="h-full rounded-full bg-emerald-500 transition-all duration-300"
                          style={{ width: fields.length ? `${(catMapped / fields.length) * 100}%` : "0%" }}
                        />
                      </div>
                    </button>

                    {/* Field rows */}
                    {isOpen && (
                      <div className="divide-y divide-border/50">
                        {fields.map((field) => {
                          const isMapped   = !!field.mappedFrom
                          const isDragOver = dragOverTarget === field.id
                          const canDrop    = !isMapped && !!draggedField

                          return (
                            <div
                              key={field.id}
                              className="grid grid-cols-2"
                            >
                              {/* Col 2: Required Model Field tile */}
                              <div
                                className={cn(
                                  "flex items-center gap-2.5 px-4 py-2.5 border-r border-border/60",
                                  isMapped
                                    ? "bg-emerald-50/40 dark:bg-emerald-950/15"
                                    : "bg-background"
                                )}
                              >
                                <div
                                  className={cn(
                                    "h-2 w-2 rounded-full shrink-0",
                                    isMapped
                                      ? "bg-emerald-500"
                                      : field.required
                                      ? "bg-destructive"
                                      : "bg-muted-foreground/30"
                                  )}
                                />
                                <span className="text-xs truncate leading-tight flex-1 text-foreground">
                                  {field.name}
                                </span>
                                <div className="shrink-0 flex items-center">
                                  {isMapped ? (
                                    <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
                                  ) : field.required ? (
                                    <span className="text-[9px] font-semibold uppercase tracking-wide text-destructive">
                                      Required
                                    </span>
                                  ) : null}
                                </div>
                              </div>

                              {/* Col 3: Drop zone / mapped tile */}
                              <div
                                onDragOver={(e) => {
                                  e.preventDefault()
                                  if (canDrop) setDragOverTarget(field.id)
                                }}
                                onDragLeave={() => setDragOverTarget(null)}
                                onDrop={(e) => {
                                  e.preventDefault()
                                  if (canDrop) handleDrop(field.id)
                                }}
                                className={cn(
                                  "flex items-center px-3 py-2 transition-all duration-150",
                                  isMapped
                                    ? "bg-emerald-50/40 dark:bg-emerald-950/15"
                                    : isDragOver
                                    ? "bg-primary/5 dark:bg-primary/10"
                                    : canDrop
                                    ? "bg-muted/20"
                                    : "bg-background"
                                )}
                              >
                                {isMapped ? (
                                  <div className="flex items-center gap-2 flex-1 min-w-0 px-2.5 py-1.5 rounded-md border bg-emerald-100 dark:bg-emerald-900/40 border-emerald-300 dark:border-emerald-700/60">
                                    <span className="flex-1 truncate text-xs text-emerald-800 dark:text-emerald-200 leading-tight font-medium">
                                      {getSourceName(field.mappedFrom!)}
                                    </span>
                                    <button
                                      onClick={() => handleRemoveMapping(field.id)}
                                      className="shrink-0 rounded p-0.5 hover:bg-emerald-200 dark:hover:bg-emerald-800 transition-colors"
                                      aria-label="Remove mapping"
                                    >
                                      <X className="h-3 w-3 text-emerald-600 dark:text-emerald-400" />
                                    </button>
                                  </div>
                                ) : (
                                  <div
                                    className={cn(
                                      "flex items-center justify-center flex-1 px-2.5 py-1.5 rounded-md border border-dashed text-xs transition-all duration-150",
                                      isDragOver
                                        ? "border-primary text-primary bg-primary/5 scale-[1.01]"
                                        : "border-border/60 text-muted-foreground/50"
                                    )}
                                  >
                                    {isDragOver ? "Drop to map field" : "Drag source field here"}
                                  </div>
                                )}
                              </div>
                            </div>
                          )
                        })}
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <DialogFooter className="shrink-0 px-6 py-4 border-t bg-card">
          <div className="flex items-center gap-2 mr-auto text-sm text-muted-foreground">
            <span>{mappedCount} of {totalCount} fields mapped</span>
            {unmappedReqd > 0 && (
              <span className="text-destructive font-medium">
                · {unmappedReqd} required {unmappedReqd === 1 ? "field" : "fields"} still need mapping
              </span>
            )}
          </div>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={() => onOpenChange(false)}>
            Save Mappings
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
