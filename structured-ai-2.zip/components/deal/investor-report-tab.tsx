"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import type { Deal } from "@/lib/data"
import { Download, RefreshCw, AlertCircle, CheckCircle2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

interface InvestorReportTabProps {
  deal: Deal
}

export function InvestorReportTab({ deal }: InvestorReportTabProps) {
  const { toast } = useToast()
  const [isRecalculating, setIsRecalculating] = useState(false)

  const report = deal.reports[0]

  const handleRecalculate = () => {
    setIsRecalculating(true)
    setTimeout(() => {
      setIsRecalculating(false)
      toast({
        title: "Report Recalculated",
        description: "Investor report updated with latest servicer data",
      })
    }, 2000)
  }

  const handleExport = () => {
    toast({
      title: "Report Exported",
      description: "Investor report downloaded as PDF",
    })
  }

  // Chart data
  const paymentData = report.classes.map((cls) => ({
    name: cls.name,
    interest: cls.interest_paid,
    principal: cls.principal_paid,
  }))

  const ocTrendData = [
    { month: "Jan", ratio: 1.05 },
    { month: "Feb", ratio: 1.04 },
    { month: "Mar", ratio: 1.04 },
    { month: "Apr", ratio: 1.03 },
    { month: "May", ratio: 1.03 },
    { month: "Jun", ratio: 1.03 },
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Investor Report</h2>
          <p className="text-muted-foreground">Distribution period: {report.period}</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleRecalculate} disabled={isRecalculating}>
            <RefreshCw className={`mr-2 h-4 w-4 ${isRecalculating ? "animate-spin" : ""}`} />
            {isRecalculating ? "Recalculating..." : "Recalculate"}
          </Button>
          <Button variant="outline" size="sm" onClick={handleExport}>
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      {/* Class Detail Table */}
      <Card>
        <CardHeader>
          <CardTitle>Class Detail</CardTitle>
          <CardDescription>Interest and principal payments by class</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Class</TableHead>
                <TableHead className="text-right">Interest Due</TableHead>
                <TableHead className="text-right">Interest Paid</TableHead>
                <TableHead className="text-right">Principal Paid</TableHead>
                <TableHead className="text-right">Balance EOP</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {report.classes.map((cls) => (
                <TableRow key={cls.name}>
                  <TableCell className="font-medium">{cls.name}</TableCell>
                  <TableCell className="text-right font-mono">${cls.interest_due.toLocaleString()}</TableCell>
                  <TableCell className="text-right font-mono">${cls.interest_paid.toLocaleString()}</TableCell>
                  <TableCell className="text-right font-mono">${cls.principal_paid.toLocaleString()}</TableCell>
                  <TableCell className="text-right font-mono">${cls.balance_eop.toLocaleString()}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Charts */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Payments by Class */}
        <Card>
          <CardHeader>
            <CardTitle>Payments by Class</CardTitle>
            <CardDescription>Interest and principal distributions</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                interest: {
                  label: "Interest",
                  color: "hsl(var(--chart-1))",
                },
                principal: {
                  label: "Principal",
                  color: "hsl(var(--chart-2))",
                },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={paymentData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="name" className="text-xs" />
                  <YAxis className="text-xs" />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="interest" fill="var(--color-interest)" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="principal" fill="var(--color-principal)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        {/* OC Ratio Trend */}
        <Card>
          <CardHeader>
            <CardTitle>OC Ratio Trend</CardTitle>
            <CardDescription>6-month overcollateralization history</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                ratio: {
                  label: "OC Ratio",
                  color: "hsl(var(--chart-3))",
                },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={ocTrendData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="month" className="text-xs" />
                  <YAxis domain={[1.0, 1.1]} className="text-xs" />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Line
                    type="monotone"
                    dataKey="ratio"
                    stroke="var(--color-ratio)"
                    strokeWidth={2}
                    dot={{ fill: "var(--color-ratio)" }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>

      {/* Coverage Tests */}
      <Card>
        <CardHeader>
          <CardTitle>Coverage Tests</CardTitle>
          <CardDescription>Trigger and performance test results</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {report.tests.map((test) => (
              <div key={test.name} className="flex items-center justify-between rounded-lg border p-4">
                <div className="flex items-center gap-4">
                  {test.pass ? (
                    <CheckCircle2 className="h-5 w-5 text-green-600" />
                  ) : (
                    <AlertCircle className="h-5 w-5 text-destructive" />
                  )}
                  <div>
                    <div className="font-medium">{test.name}</div>
                    <div className="text-sm text-muted-foreground">
                      Current value: {typeof test.value === "number" ? test.value.toFixed(2) : test.value}
                    </div>
                  </div>
                </div>
                <Badge variant={test.pass ? "default" : "destructive"}>{test.pass ? "Pass" : "Fail"}</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Accounts */}
      <Card>
        <CardHeader>
          <CardTitle>Reserve Accounts</CardTitle>
          <CardDescription>Account balances at end of period</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {Object.entries(report.accounts).map(([key, value]) => (
              <div key={key} className="flex items-center justify-between rounded-lg border p-3">
                <span className="font-medium capitalize">{key.replace(/_/g, " ")}</span>
                <span className="font-mono">${value.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Narrative */}
      <Card>
        <CardHeader>
          <CardTitle>Period Narrative</CardTitle>
          <CardDescription>AI-generated explanation of this distribution period</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-lg bg-muted p-4">
            <p className="text-sm leading-relaxed">{report.narrative}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
