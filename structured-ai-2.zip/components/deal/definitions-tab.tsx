"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import type { Deal } from "@/lib/data"
import { FileText, Edit, Network, Search } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Input } from "@/components/ui/input"
import { DefinitionDependenciesModal } from "./definition-dependencies-modal"

interface DefinitionsTabProps {
  deal: Deal
}

export function DefinitionsTab({ deal }: DefinitionsTabProps) {
  const { toast } = useToast()
  const [editingDef, setEditingDef] = useState<(typeof deal.definitions)[0] | null>(null)
  const [editedText, setEditedText] = useState("")
  const [dependenciesTerm, setDependenciesTerm] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState("")

  const filteredDefinitions = deal.definitions.filter((def) =>
    def.term.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const handleEdit = (def: (typeof deal.definitions)[0]) => {
    setEditingDef(def)
    setEditedText(def.text)
  }

  const handleSave = () => {
    toast({
      title: "Definition Updated",
      description: `Successfully updated ${editingDef?.term}`,
    })
    setEditingDef(null)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Extracted Definitions</CardTitle>
          <CardDescription>Key terms and definitions extracted from governing documents</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search terms..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Term</TableHead>
                <TableHead>Definition</TableHead>
                <TableHead>Source</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredDefinitions.length > 0 ? (
                filteredDefinitions.map((def) => (
                <TableRow key={def.id}>
                  <TableCell className="font-medium">{def.term}</TableCell>
                  <TableCell className="max-w-md">
                    <div className="line-clamp-2 text-sm text-muted-foreground">{def.text}</div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <div className="text-sm">
                        <div className="font-medium">{def.source_doc}</div>
                        <div className="text-muted-foreground">{def.section}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="sm" onClick={() => handleEdit(def)}>
                        <Edit className="mr-2 h-4 w-4" />
                        Edit
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => setDependenciesTerm(def.term)}>
                        <Network className="mr-2 h-4 w-4" />
                        Dependencies
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
              ) : (
                <TableRow>
                  <TableCell colSpan={4} className="py-8 text-center text-muted-foreground">
                    No terms found matching &quot;{searchQuery}&quot;
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Definition Dependencies */}
      <Card>
        <CardHeader>
          <CardTitle>Definition Dependencies</CardTitle>
          <CardDescription>How definitions are used across the model</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {deal.definitions.slice(0, 2).map((def) => (
              <div key={def.id} className="rounded-lg border p-4">
                <div className="mb-2 flex items-center gap-2">
                  <Badge variant="outline">{def.term}</Badge>
                  <span className="text-sm text-muted-foreground">used in 3 rules</span>
                </div>
                <div className="ml-4 space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-primary" />
                    <span>Interest Waterfall - Step 1</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-primary" />
                    <span>Principal Waterfall - Source Calculation</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-primary" />
                    <span>OC Test Calculation</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Definition Dependencies Modal */}
      <DefinitionDependenciesModal
        open={!!dependenciesTerm}
        onOpenChange={(open) => !open && setDependenciesTerm(null)}
        termName={dependenciesTerm || ""}
      />

      {/* Edit Definition Dialog */}
      <Dialog open={!!editingDef} onOpenChange={() => setEditingDef(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Definition: {editingDef?.term}</DialogTitle>
            <DialogDescription>
              Source: {editingDef?.source_doc} {editingDef?.section}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="mb-2 block text-sm font-medium">Definition Text</label>
              <Textarea
                value={editedText}
                onChange={(e) => setEditedText(e.target.value)}
                rows={6}
                className="font-mono text-sm"
              />
            </div>
            <div className="rounded-lg bg-muted p-4">
              <div className="mb-2 text-sm font-medium">Impact Analysis</div>
              <div className="text-sm text-muted-foreground">
                Changing this definition will affect 3 waterfall rules and 1 test calculation. Python code will be
                automatically regenerated.
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setEditingDef(null)}>
                Cancel
              </Button>
              <Button onClick={handleSave}>Save Changes</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
