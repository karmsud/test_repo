"use client"

import { WaterfallBuilder } from "@/components/waterfall-builder"
import { Card } from "@/components/ui/card"
import type { Deal } from "@/lib/data"

interface WaterfallBuilderTabProps {
  deal: Deal
}

export function WaterfallBuilderTab({ deal }: WaterfallBuilderTabProps) {
  return (
    <div className="space-y-4">
      <Card className="overflow-hidden border-0 shadow-lg">
        <div className="h-[calc(100vh-200px)]">
          <WaterfallBuilder />
        </div>
      </Card>
    </div>
  )
}
