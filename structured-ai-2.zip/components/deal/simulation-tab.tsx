"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import type { Deal } from "@/lib/data"
import { Play, Info, TrendingDown, TrendingUp } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface SimulationTabProps {
  deal: Deal
}

export function SimulationTab({ deal }: SimulationTabProps) {
  const { toast } = useToast()
  const [isRunning, setIsRunning] = useState(false)
  const [showExplanation, setShowExplanation] = useState(false)

  const defaults = deal.simulation_defaults
  const [cpr, setCpr] = useState(defaults.cpr * 100)
  const [cdr, setCdr] = useState(defaults.cdr * 100)
  const [severity, setSeverity] = useState(defaults.severity * 100)

  const handleRunSimulation = () => {
    setIsRunning(true)
    setTimeout(() => {
      setIsRunning(false)
      toast({
        title: "Simulation Complete",
        description: "Results updated in Investor Report tab",
      })
    }, 3000)
  }

  const handleExplain = () => {
    setShowExplanation(true)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Cashflow Simulation</h2>
          <p className="text-muted-foreground">Adjust assumptions and run scenario analysis</p>
        </div>
        <Button onClick={handleRunSimulation} disabled={isRunning}>
          <Play className={`mr-2 h-4 w-4 ${isRunning ? "animate-pulse" : ""}`} />
          {isRunning ? "Running..." : "Run Simulation"}
        </Button>
      </div>

      {/* Simulation Controls */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Prepayment Rate */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Prepayment Rate (CPR)
            </CardTitle>
            <CardDescription>Constant prepayment rate assumption</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>CPR</Label>
                <Badge variant="secondary">{cpr.toFixed(1)}%</Badge>
              </div>
              <Slider value={[cpr]} onValueChange={(v) => setCpr(v[0])} min={0} max={30} step={0.5} />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>0%</span>
                <span>30%</span>
              </div>
            </div>
            <div className="rounded-lg bg-muted p-3 text-sm text-muted-foreground">
              Higher prepayment rates reduce interest income and accelerate principal returns.
            </div>
          </CardContent>
        </Card>

        {/* Default Rate */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingDown className="h-5 w-5" />
              Default Rate (CDR)
            </CardTitle>
            <CardDescription>Constant default rate assumption</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>CDR</Label>
                <Badge variant="secondary">{cdr.toFixed(1)}%</Badge>
              </div>
              <Slider value={[cdr]} onValueChange={(v) => setCdr(v[0])} min={0} max={15} step={0.5} />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>0%</span>
                <span>15%</span>
              </div>
            </div>
            <div className="rounded-lg bg-muted p-3 text-sm text-muted-foreground">
              Higher default rates reduce available funds and may trigger OC test breaches.
            </div>
          </CardContent>
        </Card>

        {/* Loss Severity */}
        <Card>
          <CardHeader>
            <CardTitle>Loss Severity</CardTitle>
            <CardDescription>Expected loss given default</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Severity</Label>
                <Badge variant="secondary">{severity.toFixed(1)}%</Badge>
              </div>
              <Slider value={[severity]} onValueChange={(v) => setSeverity(v[0])} min={0} max={100} step={5} />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>0%</span>
                <span>100%</span>
              </div>
            </div>
            <div className="rounded-lg bg-muted p-3 text-sm text-muted-foreground">
              Severity determines the recovery amount after a default event occurs.
            </div>
          </CardContent>
        </Card>

        {/* Recovery Lag */}
        <Card>
          <CardHeader>
            <CardTitle>Recovery Lag</CardTitle>
            <CardDescription>Time to recover defaulted amounts</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Lag (months)</Label>
                <Badge variant="secondary">{defaults.recovery_lag_months}</Badge>
              </div>
              <Slider
                value={[defaults.recovery_lag_months]}
                min={0}
                max={12}
                step={1}
                disabled
                className="opacity-50"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>0</span>
                <span>12</span>
              </div>
            </div>
            <div className="rounded-lg bg-muted p-3 text-sm text-muted-foreground">
              Recovery lag affects timing of cashflows and liquidity requirements.
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Scenario Presets */}
      <Card>
        <CardHeader>
          <CardTitle>Scenario Presets</CardTitle>
          <CardDescription>Quick-load common stress scenarios</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 md:grid-cols-3">
            <Button
              variant="outline"
              className="h-auto flex-col items-start p-4 bg-transparent"
              onClick={() => {
                setCpr(8)
                setCdr(3)
                setSeverity(35)
              }}
            >
              <div className="font-semibold">Base Case</div>
              <div className="text-xs text-muted-foreground">CPR 8% / CDR 3% / Sev 35%</div>
            </Button>
            <Button
              variant="outline"
              className="h-auto flex-col items-start p-4 bg-transparent"
              onClick={() => {
                setCpr(15)
                setCdr(8)
                setSeverity(50)
              }}
            >
              <div className="font-semibold">Moderate Stress</div>
              <div className="text-xs text-muted-foreground">CPR 15% / CDR 8% / Sev 50%</div>
            </Button>
            <Button
              variant="outline"
              className="h-auto flex-col items-start p-4 bg-transparent"
              onClick={() => {
                setCpr(20)
                setCdr(12)
                setSeverity(70)
              }}
            >
              <div className="font-semibold">Severe Stress</div>
              <div className="text-xs text-muted-foreground">CPR 20% / CDR 12% / Sev 70%</div>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Simulation Results Preview */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Expected Impact</CardTitle>
              <CardDescription>Projected effects of current assumptions</CardDescription>
            </div>
            <Button variant="ghost" size="sm" onClick={handleExplain}>
              <Info className="mr-2 h-4 w-4" />
              Explain This Month
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="rounded-lg border p-4">
              <div className="text-sm text-muted-foreground">Projected OC Ratio</div>
              <div className="mt-2 text-2xl font-bold">
                {(1.03 - (cdr / 100) * 0.5 + ((8 - cpr) / 100) * 0.2).toFixed(2)}
              </div>
              <div className="mt-1 text-xs text-muted-foreground">
                {1.03 - (cdr / 100) * 0.5 + ((8 - cpr) / 100) * 0.2 >= 1.03 ? "Above threshold" : "Below threshold"}
              </div>
            </div>
            <div className="rounded-lg border p-4">
              <div className="text-sm text-muted-foreground">Principal Mode</div>
              <div className="mt-2 text-2xl font-bold">
                {1.03 - (cdr / 100) * 0.5 + ((8 - cpr) / 100) * 0.2 >= 1.03 ? "Pro-Rata" : "Sequential"}
              </div>
              <div className="mt-1 text-xs text-muted-foreground">Based on OC test result</div>
            </div>
            <div className="rounded-lg border p-4">
              <div className="text-sm text-muted-foreground">Expected Losses</div>
              <div className="mt-2 text-2xl font-bold">${((cdr / 100) * (severity / 100) * 12000000).toFixed(0)}</div>
              <div className="mt-1 text-xs text-muted-foreground">This distribution period</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Explanation Dialog */}
      <Dialog open={showExplanation} onOpenChange={setShowExplanation}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Simulation Explanation</DialogTitle>
            <DialogDescription>AI-generated narrative for current scenario</DialogDescription>
          </DialogHeader>
          <ScrollArea className="h-[400px]">
            <div className="space-y-4 pr-4">
              <div className="rounded-lg bg-muted p-4">
                <div className="mb-2 font-semibold">Scenario Overview</div>
                <p className="text-sm text-muted-foreground">
                  With a CPR of {cpr.toFixed(1)}% and CDR of {cdr.toFixed(1)}%, the pool is experiencing{" "}
                  {cdr > 5 ? "elevated" : "normal"} default rates and {cpr > 10 ? "high" : "moderate"} prepayment
                  activity.
                </p>
              </div>

              <div className="rounded-lg bg-muted p-4">
                <div className="mb-2 font-semibold">OC Test Impact</div>
                <p className="text-sm text-muted-foreground">
                  The projected OC Ratio of {(1.03 - (cdr / 100) * 0.5 + ((8 - cpr) / 100) * 0.2).toFixed(2)} is{" "}
                  {1.03 - (cdr / 100) * 0.5 + ((8 - cpr) / 100) * 0.2 >= 1.03 ? "above" : "below"} the 1.03 threshold.
                  Principal will be distributed in{" "}
                  {1.03 - (cdr / 100) * 0.5 + ((8 - cpr) / 100) * 0.2 >= 1.03 ? "pro-rata" : "sequential"} mode per
                  Indenture §5.04(b).
                </p>
              </div>

              <div className="rounded-lg bg-muted p-4">
                <div className="mb-2 font-semibold">Cashflow Implications</div>
                <p className="text-sm text-muted-foreground">
                  Expected losses of ${((cdr / 100) * (severity / 100) * 12000000).toFixed(0)} will reduce Available
                  Funds. Interest payments to all classes should be covered, but principal distributions may be
                  impacted.
                </p>
              </div>

              <div className="rounded-lg bg-muted p-4">
                <div className="mb-2 font-semibold">Document References</div>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">§5.04(b)</Badge>
                    <span className="text-muted-foreground">Principal allocation mode determination</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">§4.01(a)-(f)</Badge>
                    <span className="text-muted-foreground">Priority of payments waterfall</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">§1.01</Badge>
                    <span className="text-muted-foreground">Available Funds definition</span>
                  </div>
                </div>
              </div>
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  )
}
