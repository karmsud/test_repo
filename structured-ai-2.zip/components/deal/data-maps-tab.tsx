"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import type { Deal } from "@/lib/data"
import { ArrowRight, Database, Plus, Edit } from "lucide-react"
import { DataMappingModal } from "./data-mapping-modal"
import { useToast } from "@/hooks/use-toast"

interface DataMapsTabProps {
  deal: Deal
}

export function DataMapsTab({ deal }: DataMapsTabProps) {
  const { toast } = useToast()
  const [selectedMap, setSelectedMap] = useState<string | null>(null)

  const handleNewMap = () => {
    const input = document.createElement("input")
    input.type = "file"
    input.accept = ".csv,.xlsx,.xls,.json"
    input.onchange = (e: any) => {
      const file = e.target.files?.[0]
      if (file) {
        toast({
          title: "File Selected",
          description: `Selected: ${file.name} (${(file.size / 1024 / 1024).toFixed(2)} MB)`,
        })
      }
    }
    input.click()
  }
  const dataMaps = [
    {
      id: 1,
      name: "Loan Schedule",
      source: "Loan Tape",
      target: "Python Model",
      fields: 12,
      status: "incomplete",
      statusDetails: "8 fields unmapped..",
    },
    {
      id: 2,
      name: "Bond Details",
      source: "Offering Documents",
      target: "Investor Report",
      fields: 8,
      status: "complete",
      statusDetails: "",
    },
    {
      id: 3,
      name: "Collateral Loan Data",
      source: "Loan Level File",
      target: "LTV Calculations",
      fields: 15,
      status: "complete",
      statusDetails: "",
    },
    {
      id: 4,
      name: "Payment Schedule",
      source: "Loan Agreement",
      target: "Waterfall Engine",
      fields: 10,
      status: "pending",
      statusDetails: "Currently in Automation Queue",
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "incomplete":
        return { backgroundColor: "rgb(207, 42, 54)" }
      case "complete":
        return { backgroundColor: "rgb(34, 197, 94)" }
      case "pending":
        return { backgroundColor: "rgb(251, 191, 36)" }
      default:
        return {}
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "incomplete":
        return "Incomplete"
      case "complete":
        return "Complete"
      case "pending":
        return "Pending"
      default:
        return status
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Data Maps</CardTitle>
            <CardDescription>Define mappings between source documents and model components</CardDescription>
          </div>
          <Button onClick={handleNewMap} size="sm" className="gap-2">
            <Plus className="h-4 w-4" />
            New Map
          </Button>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Map Name</TableHead>
                <TableHead>Source</TableHead>
                <TableHead>Fields</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Status Details</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {dataMaps.map((map) => (
                <TableRow key={map.id}>
                  <TableCell className="font-medium">{map.name}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Database className="h-4 w-4 text-muted-foreground" />
                      {map.source}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="secondary">{map.fields} fields</Badge>
                  </TableCell>
                  <TableCell>
                    <Badge style={getStatusColor(map.status)} className="text-white">
                      {getStatusLabel(map.status)}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">{map.statusDetails}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm" onClick={() => setSelectedMap(map.name)}>
                      <Edit className="mr-2 h-4 w-4" />
                      Edit
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <DataMappingModal
        open={!!selectedMap}
        onOpenChange={(open) => !open && setSelectedMap(null)}
        mapName={selectedMap || ""}
      />
    </div>
  )
}
