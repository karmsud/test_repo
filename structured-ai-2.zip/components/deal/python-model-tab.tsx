"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { Deal } from "@/lib/data"
import { Code, Type, Download, Play, FileText } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface PythonModelTabProps {
  deal: Deal
}

export function PythonModelTab({ deal }: PythonModelTabProps) {
  const { toast } = useToast()
  const [viewMode, setViewMode] = useState<"python" | "english">("python")
  const [hoveredLine, setHoveredLine] = useState<number | null>(null)

  const handleRun = () => {
    toast({
      title: "Model Executed",
      description: "Python model ran successfully. Check the Investor Report tab for results.",
    })
  }

  const handleExport = () => {
    toast({
      title: "Model Exported",
      description: "Python model downloaded as cashflow_model.py",
    })
  }

  // Parse Python code into lines with metadata
  const codeLines = deal.python_model.split("\n")
  const sourceMap: Record<number, { doc: string; section: string; excerpt: string }> = {
    8: {
      doc: "Trust & Servicing Agreement.pdf",
      section: "§4.01(a)",
      excerpt: "Available Funds shall be applied: first to Servicer Fee...",
    },
    9: {
      doc: "Trust & Servicing Agreement.pdf",
      section: "§4.01(b)",
      excerpt: "...second to Trustee Fee...",
    },
    10: {
      doc: "Indenture.pdf",
      section: "§4.02",
      excerpt: "...third to Class A Interest...",
    },
    18: {
      doc: "Indenture.pdf",
      section: "§5.04(b)",
      excerpt: "If OC Ratio is less than 3.00%, principal shall be applied sequentially.",
    },
  }

  return (
    <div className="space-y-6">
      {/* Header with Actions */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Generated Python Model</h2>
          <p className="text-muted-foreground">Auto-generated cashflow model from governing documents</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleRun}>
            <Play className="mr-2 h-4 w-4" />
            Run Model
          </Button>
          <Button variant="outline" size="sm" onClick={handleExport}>
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      {/* Dual View Toggle */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Model Code</CardTitle>
              <CardDescription>Toggle between Python code and plain English interpretation</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant={viewMode === "python" ? "default" : "outline"}
                size="sm"
                onClick={() => setViewMode("python")}
              >
                <Code className="mr-2 h-4 w-4" />
                Python
              </Button>
              <Button
                variant={viewMode === "english" ? "default" : "outline"}
                size="sm"
                onClick={() => setViewMode("english")}
              >
                <Type className="mr-2 h-4 w-4" />
                English
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 lg:grid-cols-3">
            {/* Main Code/English View */}
            <div className="lg:col-span-2">
              {viewMode === "python" ? (
                <ScrollArea className="h-[600px] rounded-lg border">
                  <div className="relative">
                    <pre className="p-4 font-mono text-sm">
                      {codeLines.map((line, idx) => (
                        <div
                          key={idx}
                          className={`group relative ${hoveredLine === idx ? "bg-primary/10" : ""}`}
                          onMouseEnter={() => setHoveredLine(idx)}
                          onMouseLeave={() => setHoveredLine(null)}
                        >
                          <span className="inline-block w-12 select-none text-muted-foreground">{idx + 1}</span>
                          <code className={line.trim().startsWith("#") ? "text-muted-foreground" : ""}>{line}</code>
                          {sourceMap[idx] && (
                            <div className="absolute right-2 top-0 opacity-0 transition-opacity group-hover:opacity-100">
                              <Badge variant="outline" className="text-xs">
                                <FileText className="mr-1 h-3 w-3" />
                                {sourceMap[idx].section}
                              </Badge>
                            </div>
                          )}
                        </div>
                      ))}
                    </pre>
                  </div>
                </ScrollArea>
              ) : (
                <ScrollArea className="h-[600px] rounded-lg border bg-muted/30 p-6">
                  <div className="space-y-6">
                    {deal.english_rules.map((rule) => (
                      <div key={rule.rule_id} className="rounded-lg border bg-card p-4">
                        <div className="mb-2 flex items-center gap-2">
                          <Badge variant="outline">{rule.rule_id}</Badge>
                          <span className="text-xs text-muted-foreground font-mono">{rule.python_hint}</span>
                        </div>
                        <p className="text-sm leading-relaxed">{rule.english}</p>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </div>

            {/* Document Lineage Panel */}
            <div className="lg:col-span-1">
              <div className="sticky top-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Document Lineage</CardTitle>
                    <CardDescription className="text-xs">Source references for selected code</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-[520px]">
                      {hoveredLine !== null && sourceMap[hoveredLine] ? (
                        <div className="space-y-4">
                          <div>
                            <div className="mb-2 text-xs font-medium text-muted-foreground">Source Document</div>
                            <div className="flex items-start gap-2">
                              <FileText className="mt-0.5 h-4 w-4 text-muted-foreground" />
                              <div className="text-sm">
                                <div className="font-medium">{sourceMap[hoveredLine].doc}</div>
                                <Badge variant="outline" className="mt-1">
                                  {sourceMap[hoveredLine].section}
                                </Badge>
                              </div>
                            </div>
                          </div>
                          <div>
                            <div className="mb-2 text-xs font-medium text-muted-foreground">Extracted Clause</div>
                            <p className="rounded-lg bg-muted p-3 text-xs leading-relaxed">
                              {sourceMap[hoveredLine].excerpt}
                            </p>
                          </div>
                          <div>
                            <div className="mb-2 text-xs font-medium text-muted-foreground">Line Reference</div>
                            <Badge variant="secondary">Line {hoveredLine + 1}</Badge>
                          </div>
                        </div>
                      ) : (
                        <div className="flex h-full items-center justify-center text-center">
                          <div className="text-sm text-muted-foreground">
                            Hover over code lines to see source document references
                          </div>
                        </div>
                      )}
                    </ScrollArea>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Rule References */}
      <Card>
        <CardHeader>
          <CardTitle>Rule References</CardTitle>
          <CardDescription>Complete mapping between rules and source documents</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue={deal.rule_references[0]?.rule_id} className="w-full">
            <TabsList>
              {deal.rule_references.map((ref) => (
                <TabsTrigger key={ref.rule_id} value={ref.rule_id}>
                  {ref.rule_id}
                </TabsTrigger>
              ))}
            </TabsList>
            {deal.rule_references.map((ref) => (
              <TabsContent key={ref.rule_id} value={ref.rule_id} className="space-y-4">
                {ref.sources.map((source, idx) => (
                  <div key={idx} className="rounded-lg border p-4">
                    <div className="mb-3 flex items-center gap-2">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <span className="font-medium">{source.doc}</span>
                      <Badge variant="outline">{source.section}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{source.excerpt}</p>
                  </div>
                ))}
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
