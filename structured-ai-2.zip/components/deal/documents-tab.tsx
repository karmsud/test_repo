"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import type { Deal } from "@/lib/data"
import { FileText, Eye, Download, Sparkles, Plus } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface DocumentsTabProps {
  deal: Deal
}

export function DocumentsTab({ deal }: DocumentsTabProps) {
  const { toast } = useToast()
  const [selectedDoc, setSelectedDoc] = useState<(typeof deal.documents)[0] | null>(null)
  const [isExtracting, setIsExtracting] = useState(false)

  const handleUpload = () => {
    const input = document.createElement("input")
    input.type = "file"
    input.accept = ".pdf,.doc,.docx"
    input.onchange = (e: any) => {
      const file = e.target.files?.[0]
      if (file) {
        toast({
          title: "File Selected",
          description: `Selected: ${file.name} (${(file.size / 1024 / 1024).toFixed(2)} MB)`,
        })
      }
    }
    input.click()
  }

  const handleExtract = (docName: string) => {
    setIsExtracting(true)
    setTimeout(() => {
      setIsExtracting(false)
      toast({
        title: "Extraction Complete",
        description: `Successfully extracted sections from ${docName}`,
      })
    }, 2000)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Governing Documents</CardTitle>
            <CardDescription>Legal documents that define the deal structure and cashflow rules</CardDescription>
          </div>
          <Button onClick={handleUpload} className="gap-2">
            <Plus className="h-4 w-4" />
            New Document
          </Button>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Document Name</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Pages</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {deal.documents.map((doc) => (
                <TableRow key={doc.name}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      {doc.name}
                    </div>
                  </TableCell>
                  <TableCell>{doc.type}</TableCell>
                  <TableCell>{doc.pages}</TableCell>
                  <TableCell>
                    <Badge variant={doc.status === "Parsed" ? "default" : "secondary"}>{doc.status}</Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="sm" onClick={() => setSelectedDoc(doc)}>
                        <Eye className="mr-2 h-4 w-4" />
                        View
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => handleExtract(doc.name)} disabled={isExtracting}>
                        <Sparkles className="mr-2 h-4 w-4" />
                        {isExtracting ? "Extracting..." : "Extract"}
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Document Sections Overview */}
      {deal.documents.length > 0 && deal.documents[0].sections && (
        <Card>
          <CardHeader>
            <CardTitle>Extracted Sections</CardTitle>
            <CardDescription>Key sections identified from governing documents</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2">
              {Object.entries(deal.documents[0].sections).map(([key, sections]) => (
                <div key={key} className="rounded-lg border p-4">
                  <div className="mb-2 text-sm font-medium capitalize">{key.replace(/_/g, " ")}</div>
                  <div className="flex flex-wrap gap-2">
                    {sections.map((section, idx) => (
                      <Badge key={idx} variant="outline">
                        {section}
                      </Badge>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Document Viewer Dialog */}
      <Dialog open={!!selectedDoc} onOpenChange={() => setSelectedDoc(null)}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>{selectedDoc?.name}</DialogTitle>
            <DialogDescription>
              {selectedDoc?.type} • {selectedDoc?.pages} pages
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="h-[500px] rounded-md border p-4">
            <div className="space-y-4 font-mono text-sm">
              <div className="rounded-lg bg-muted p-4">
                <div className="mb-2 font-semibold">§1.01 Definitions</div>
                <p className="text-muted-foreground">
                  "Available Funds" means, with respect to any Distribution Date, all amounts received by the Servicer
                  from or on behalf of the Obligors during the related Collection Period, including all Principal
                  Collections, Interest Collections, and Recoveries...
                </p>
              </div>
              <div className="rounded-lg bg-muted p-4">
                <div className="mb-2 font-semibold">§4.01 Priority of Payments</div>
                <p className="text-muted-foreground">
                  On each Distribution Date, Available Funds shall be applied in the following order of priority: (a)
                  first, to pay the Servicer Fee; (b) second, to pay the Trustee Fee; (c) third, to pay interest due on
                  the Class A Notes...
                </p>
              </div>
              <div className="rounded-lg bg-muted p-4">
                <div className="mb-2 font-semibold">§5.03 Overcollateralization Test</div>
                <p className="text-muted-foreground">
                  The "OC Ratio" shall be calculated as (Collateral Balance minus Subordinate Notes Balance) divided by
                  Collateral Balance. If the OC Ratio falls below 3.00%, the Trigger Event shall be deemed to have
                  occurred...
                </p>
              </div>
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  )
}
