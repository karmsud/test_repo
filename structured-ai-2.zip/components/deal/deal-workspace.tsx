"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AIChatPanel, AIChatButton } from "@/components/ai-chat-panel"
import { ArrowLeft } from "lucide-react"
import { DocumentsTab } from "@/components/deal/documents-tab"
import { DefinitionsTab } from "@/components/deal/definitions-tab"
import { DataMapsTab } from "@/components/deal/data-maps-tab"
import { WaterfallTab } from "@/components/deal/waterfall-tab"
import { PythonModelTab } from "@/components/deal/python-model-tab"
import { InvestorReportTab } from "@/components/deal/investor-report-tab"
import { SimulationTab } from "@/components/deal/simulation-tab"
import { WaterfallBuilderTab } from "@/components/deal/waterfall-builder-tab"
import type { Deal } from "@/lib/data"

interface DealWorkspaceProps {
  deal: Deal
}

export function DealWorkspace({ deal }: DealWorkspaceProps) {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("documents")
  const [isAIChatOpen, setIsAIChatOpen] = useState(false)

  return (
    <div className="h-screen bg-background overflow-hidden">
      <AIChatPanel isOpen={isAIChatOpen} onClose={() => setIsAIChatOpen(false)} />

      <div
        className="flex h-full flex-col transition-all duration-300 ease-out"
        style={{ marginRight: isAIChatOpen ? "420px" : "0" }}
      >

      {/* Top Navigation */}
      <header className="shrink-0 border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60 z-50">
        <div className="flex h-16 items-center gap-4 px-6">
          <Button variant="ghost" size="icon" onClick={() => router.push("/dashboard")}>
            <ArrowLeft className="h-4 w-4" />
          </Button>

          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <svg className="h-5 w-5 text-primary-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                />
              </svg>
            </div>
            <div>
              <div className="text-sm font-semibold">{deal.deal_id}</div>
              <div className="text-xs text-muted-foreground">{deal.asset_type}</div>
            </div>
          </div>

          <div className="ml-auto flex items-center gap-2">
            <AIChatButton onClick={() => setIsAIChatOpen(true)} />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex flex-1 flex-col min-h-0">
        {/* Sticky Tab Bar */}
        <div className="shrink-0 border-b bg-background px-6 pt-4">
          <TabsList className="grid w-full grid-cols-8">
            <TabsTrigger value="documents">Documents</TabsTrigger>
            <TabsTrigger value="definitions">Definitions</TabsTrigger>
            <TabsTrigger value="maps">Data Maps</TabsTrigger>
            <TabsTrigger value="waterfall">Waterfall Rules</TabsTrigger>
            <TabsTrigger value="python">Python Model</TabsTrigger>
            <TabsTrigger value="builder">Waterfall Builder</TabsTrigger>
            <TabsTrigger value="report">Investor Report</TabsTrigger>
            <TabsTrigger value="simulation">Simulation</TabsTrigger>
          </TabsList>
        </div>

        {/* Scrollable Tab Content */}
        <div className="flex-1 overflow-y-auto min-h-0">
          <TabsContent value="builder" className="mt-0 h-full">
            <div className="p-6">
              <WaterfallBuilderTab deal={deal} />
            </div>
          </TabsContent>

          <div className="mx-auto max-w-7xl p-6">
            <TabsContent value="documents" className="space-y-4 mt-0">
              <DocumentsTab deal={deal} />
            </TabsContent>

            <TabsContent value="definitions" className="space-y-4 mt-0">
              <DefinitionsTab deal={deal} />
            </TabsContent>

            <TabsContent value="maps" className="space-y-4 mt-0">
              <DataMapsTab deal={deal} />
            </TabsContent>

            <TabsContent value="waterfall" className="space-y-4 mt-0">
              <WaterfallTab deal={deal} />
            </TabsContent>

            <TabsContent value="python" className="space-y-4 mt-0">
              <PythonModelTab deal={deal} />
            </TabsContent>

            <TabsContent value="report" className="space-y-4 mt-0">
              <InvestorReportTab deal={deal} />
            </TabsContent>

            <TabsContent value="simulation" className="space-y-4 mt-0">
              <SimulationTab deal={deal} />
            </TabsContent>
          </div>
        </div>
      </Tabs>
      </div>
    </div>
  )
}
