"use client"

import { useState, useMemo, useCallback } from "react"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { X, ChevronRight, ChevronDown, Maximize2, Minimize2 } from "lucide-react"
import { cn } from "@/lib/utils"

interface DefinitionDependenciesModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  termName: string
}

// Full definitions data store with {TermName} references
const FULL_DEFINITIONS: Record<string, string> = {
  "Available Funds": "All amounts received from the {Servicer} for the related {Distribution Date}, excluding {Advance Reversals} and investment income, but including {Recoveries}.",
  "OC Ratio": "({Collateral Balance} – {Subordinate Notes}) / {Collateral Balance}.",
  "Reserve Account": "An account funded to maintain a balance equal to 0.50% of the {Pool Balance} as of the {Closing Date}.",
  "Servicer": "AI Hackathon Servicing, LLC.",
  "Distribution Date": "The 25th day of each calendar month, or if such 25th day is not a {Business Day}, the next succeeding {Business Day}. The first distribution date is the 5th {Business Day} after the {Closing Date}.",
  "Business Day": "Any day other than a Saturday, Sunday, or a day on which banking institutions in New York, New York are authorized or obligated by law or executive order to be closed.",
  "Closing Date": "January 2, 2026.",
  "Advance Reversals": "Any amounts that were previously advanced by the {Servicer} and are subsequently deemed to be non-recoverable by the {Master Servicer}.",
  "Master Servicer": "AI Hackathon Master Servicing Corp., a Delaware corporation.",
  "Recoveries": "All amounts collected on {Defaulted Loans} after the applicable {Charge-Off Date}, net of any expenses incurred in connection with such collection efforts.",
  "Defaulted Loans": "Any {Mortgage Loan} that has become 180 or more days delinquent or has been foreclosed upon.",
  "Mortgage Loan": "Each residential mortgage loan transferred and assigned to the {Issuing Entity} pursuant to the {Trust Agreement}.",
  "Issuing Entity": "AI Hackathon 2026-1 Trust, a Delaware statutory trust.",
  "Trust Agreement": "The agreement dated as of the {Closing Date} among the {Depositor}, the {Issuing Entity}, and the {Indenture Trustee}.",
  "Depositor": "AI Hackathon Depositor, LLC, a Delaware limited liability company.",
  "Indenture Trustee": "U.S. Bank National Association, a national banking association.",
  "Charge-Off Date": "The date on which a {Mortgage Loan} is classified as a {Defaulted Loan} by the {Servicer}.",
  "Defaulted Loan": "See {Defaulted Loans}.",
  "Collateral Balance": "The aggregate unpaid principal balance of all {Mortgage Loan}s in the Trust as of the applicable {Distribution Date}.",
  "Subordinate Notes": "The Class B Notes issued pursuant to the {Indenture} having a subordinate claim on the {Available Funds}.",
  "Pool Balance": "The aggregate outstanding principal balance of all {Mortgage Loan}s as of the {Cut-Off Date}.",
  "Cut-Off Date": "December 1, 2025.",
  "Indenture": "The agreement dated as of the {Closing Date} between the {Issuing Entity} and the {Indenture Trustee}.",
}

// Extract unique references from a definition text
function extractReferences(text: string): string[] {
  const regex = /\{([^}]+)\}/g
  const matches: string[] = []
  let match
  while ((match = regex.exec(text)) !== null) {
    const term = match[1]
    if (!matches.includes(term)) {
      matches.push(term)
    }
  }
  return matches
}

// Count total unique dependencies recursively
function countTotalDependencies(term: string, visited: Set<string> = new Set()): number {
  if (visited.has(term)) return 0
  visited.add(term)
  
  const definition = FULL_DEFINITIONS[term]
  if (!definition) return 0
  
  const refs = extractReferences(definition)
  let count = refs.length
  
  for (const ref of refs) {
    count += countTotalDependencies(ref, visited)
  }
  
  return count
}

interface TreeNodeProps {
  term: string
  ancestors: string[]
  expandedNodes: Set<string>
  onToggle: (term: string) => void
  onExpandTerm: (term: string) => void
  depth: number
}

function TreeNode({ term, ancestors, expandedNodes, onToggle, onExpandTerm, depth }: TreeNodeProps) {
  const definition = FULL_DEFINITIONS[term]
  const isExpanded = expandedNodes.has(term)
  const isCircular = ancestors.includes(term)
  const references = definition ? extractReferences(definition) : []
  const hasChildren = references.length > 0
  
  // Render definition text with clickable links
  const renderDefinitionText = (text: string) => {
    const parts: React.ReactNode[] = []
    let lastIndex = 0
    const regex = /\{([^}]+)\}/g
    let match
    
    while ((match = regex.exec(text)) !== null) {
      // Add text before match
      if (match.index > lastIndex) {
        parts.push(text.slice(lastIndex, match.index))
      }
      
      const refTerm = match[1]
      parts.push(
        <button
          key={`${match.index}-${refTerm}`}
          className="text-primary underline underline-offset-2 hover:text-primary/80 transition-colors"
          onClick={(e) => {
            e.stopPropagation()
            onExpandTerm(refTerm)
          }}
        >
          {refTerm}
        </button>
      )
      
      lastIndex = match.index + match[0].length
    }
    
    // Add remaining text
    if (lastIndex < text.length) {
      parts.push(text.slice(lastIndex))
    }
    
    return parts
  }
  
  if (isCircular) {
    return (
      <div 
        className="flex items-center gap-2 py-1.5 px-2 rounded hover:bg-muted/50"
        style={{ marginLeft: depth * 16 }}
      >
        <span className="w-4 h-4 flex items-center justify-center text-muted-foreground text-xs">&#9679;</span>
        <span className="font-medium text-sm">{term}</span>
        <span className="text-xs text-muted-foreground italic">(circular)</span>
      </div>
    )
  }
  
  return (
    <div style={{ marginLeft: depth * 16 }}>
      <div 
        className={cn(
          "flex items-center gap-2 py-1.5 px-2 rounded cursor-pointer hover:bg-muted/50 transition-colors",
          depth > 0 && "border-l-2 border-border"
        )}
        onClick={() => onToggle(term)}
      >
        {hasChildren ? (
          isExpanded ? (
            <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />
          ) : (
            <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
          )
        ) : (
          <span className="w-4 h-4 flex items-center justify-center text-muted-foreground text-xs shrink-0">&#9679;</span>
        )}
        <span className="font-semibold text-sm">{term}</span>
        {hasChildren && (
          <Badge variant="secondary" className="text-xs px-1.5 py-0">
            {references.length} refs
          </Badge>
        )}
      </div>
      
      {isExpanded && definition && (
        <div className="ml-6 mt-1 mb-2" style={{ marginLeft: depth * 16 + 24 }}>
          {/* Definition text box */}
          <div className="bg-muted/50 rounded-md p-3 text-sm text-foreground border border-border/50 mb-2">
            {renderDefinitionText(definition)}
          </div>
          
          {/* Child nodes */}
          {references.map((ref) => (
            <TreeNode
              key={ref}
              term={ref}
              ancestors={[...ancestors, term]}
              expandedNodes={expandedNodes}
              onToggle={onToggle}
              onExpandTerm={onExpandTerm}
              depth={depth + 1}
            />
          ))}
        </div>
      )}
    </div>
  )
}

export function DefinitionDependenciesModal({ open, onOpenChange, termName }: DefinitionDependenciesModalProps) {
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set())
  
  const totalDependencies = useMemo(() => countTotalDependencies(termName), [termName])
  
  const handleToggle = useCallback((term: string) => {
    setExpandedNodes((prev) => {
      const next = new Set(prev)
      if (next.has(term)) {
        next.delete(term)
      } else {
        next.add(term)
      }
      return next
    })
  }, [])
  
  const handleExpandTerm = useCallback((term: string) => {
    setExpandedNodes((prev) => {
      const next = new Set(prev)
      next.add(term)
      return next
    })
  }, [])
  
  // Expand all nodes recursively
  const expandAll = useCallback(() => {
    const allTerms = new Set<string>()
    
    const collectTerms = (term: string, visited: Set<string>) => {
      if (visited.has(term)) return
      visited.add(term)
      allTerms.add(term)
      
      const definition = FULL_DEFINITIONS[term]
      if (!definition) return
      
      const refs = extractReferences(definition)
      for (const ref of refs) {
        collectTerms(ref, visited)
      }
    }
    
    collectTerms(termName, new Set())
    setExpandedNodes(allTerms)
  }, [termName])
  
  // Collapse all nodes
  const collapseAll = useCallback(() => {
    setExpandedNodes(new Set())
  }, [])
  
  // Reset expanded state when modal opens with new term - expand root by default
  useMemo(() => {
    if (open) {
      setExpandedNodes(new Set([termName]))
    }
  }, [open, termName])
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent 
        className="flex flex-col p-0 gap-0 overflow-hidden"
        style={{ maxWidth: "700px", width: "700px", height: "550px", maxHeight: "550px" }}
      >
        {/* Header */}
        <div className="flex items-center justify-start gap-4 px-6 py-4 border-b shrink-0">
          <h2 className="text-lg font-semibold">Dependencies: {termName}</h2>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={expandAll}>
              <Maximize2 className="w-4 h-4 mr-1" />
              Expand All
            </Button>
            <Button variant="outline" size="sm" onClick={collapseAll}>
              <Minimize2 className="w-4 h-4 mr-1" />
              Collapse All
            </Button>
          </div>
        </div>
        
        {/* Body (scrollable) */}
        <div className="flex-1 overflow-y-auto p-4">
          <TreeNode
            term={termName}
            ancestors={[]}
            expandedNodes={expandedNodes}
            onToggle={handleToggle}
            onExpandTerm={handleExpandTerm}
            depth={0}
          />
        </div>
        
        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-3 border-t bg-muted/30 shrink-0">
          <span className="text-sm text-muted-foreground">
            {totalDependencies} total dependencies
          </span>
        </div>
      </DialogContent>
    </Dialog>
  )
}
