"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Trash2, Calculator, FileText, Code, Type } from "lucide-react"
import { useState, useEffect } from "react"
import type { Node } from "@/components/waterfall-builder"

interface ConfigPanelProps {
  selectedNode: Node | null
  onUpdateAmount: (id: string, amount: number) => void
  onUpdatePayTo: (id: string, payTo: string) => void
  onUpdateLabel: (id: string, label: string) => void
  onUpdateDue: (id: string, due: number) => void
  onDeleteNode: (id: string) => void
}

function PythonIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" className={className}>
      <path
        d="M9.585 11.692h4.328s2.432.039 2.432-2.35V5.391S16.714 3 11.749 3C7.447 3 7.5 3 7.5 3l-.006 2.347h4.255v.645H5.282s-2.282-.259-2.282 4.319c0 4.578 1.995 4.417 1.995 4.417h1.19V12.5s-.108-1.996 1.962-1.996l4.438-.812z"
        fill="#3776AB"
      />
      <path
        d="M14.415 12.308h-4.328s-2.432-.039-2.432 2.35v3.951S7.286 21 12.251 21c4.302 0 4.249 0 4.249 0l.006-2.347h-4.255v-.645h6.467s2.282.259 2.282-4.319c0-4.578-1.995-4.417-1.995-4.417h-1.19V11.5s.108 1.996-1.962 1.996l-4.438.812z"
        fill="#FFD43B"
      />
      <circle cx="8.5" cy="7.5" r="0.9" fill="white" />
      <circle cx="15.5" cy="16.5" r="0.9" fill="white" />
    </svg>
  )
}

const INTEREST_CALC_DATA: Record<string, { balance: string; rate: string; days: string }> = {
  "Class A Interest": { balance: "40000000", rate: "5.25", days: "30" },
  "Class B Interest": { balance: "11538461", rate: "6.50", days: "30" },
  "Section 4.01(A)(i)": { balance: "74442", rate: "6.50", days: "31" },
}

function getInterestCalcDefaults(node: Node) {
  const preset = INTEREST_CALC_DATA[node.label || ""]
  if (preset) return preset
  return {
    balance: node.due ? String(Math.round(node.due * 12)) : String(node.amount),
    rate: "5.00",
    days: "30",
  }
}

export function ConfigPanel({
  selectedNode,
  onUpdateAmount,
  onUpdatePayTo,
  onUpdateLabel,
  onUpdateDue,
  onDeleteNode,
}: ConfigPanelProps) {
  const [balance, setBalance] = useState("")
  const [interestRate, setInterestRate] = useState("")
  const [accrualDay, setAccrualDay] = useState("")
  const [showPythonCode, setShowPythonCode] = useState(false)
  const [codeViewMode, setCodeViewMode] = useState<"python" | "english">("python")
  const [calcOpen, setCalcOpen] = useState(false)

  // Reset calc fields to demo defaults whenever the dialog opens or node changes
  useEffect(() => {
    if (calcOpen && selectedNode?.type === "interest-payment") {
      const defaults = getInterestCalcDefaults(selectedNode)
      setBalance(defaults.balance)
      setInterestRate(defaults.rate)
      setAccrualDay(defaults.days)
    }
  }, [calcOpen, selectedNode?.id])

  const getEnglishExplanation = (node: Node) => {
    const nodeTypeMap: Record<string, string> = {
      "available-fund": `This node represents the Available Funds for the current payment period. The amount of $${node.amount.toLocaleString()} is calculated by aggregating all collections received during the period, including principal payments, interest payments, and any prepayments from the underlying collateral pool. These funds are then distributed according to the priority of payments defined in the waterfall structure.`,
      "remaining-fund": `This node represents the Remaining Funds after all priority payments have been made. The amount of $${node.amount.toLocaleString()} represents excess funds that remain after satisfying all senior obligations. These remaining funds may be distributed to subordinate classes or retained in reserve accounts depending on the transaction structure and performance triggers.`,
      "interest-payment": `This node calculates and distributes interest payments to ${node.payTo || "the specified class"}. The payment amount of $${node.amount.toLocaleString()} is calculated based on the outstanding principal balance multiplied by the applicable interest rate for the accrual period. ${node.due ? `The amount due for this period is $${node.due.toLocaleString()}.` : ""} Interest payments are typically made on a monthly basis according to the payment date schedule.`,
      "principal-payment": `This node handles principal payments to ${node.payTo || "the specified class"}. The payment amount of $${node.amount.toLocaleString()} represents the principal distribution for this period. ${node.due ? `The scheduled principal due is $${node.due.toLocaleString()}.` : ""} Principal payments may be sequential or pro-rata depending on the transaction structure and whether certain performance tests are satisfied.`,
    }
    return nodeTypeMap[node.type] || "This node represents a payment step in the waterfall structure."
  }

  return (
    <div className="w-80 h-full bg-sidebar border-l border-sidebar-border flex flex-col">
      <div className="p-4 border-b border-sidebar-border flex-shrink-0 flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-sidebar-foreground">Configuration</h2>
          <p className="text-sm text-muted-foreground">Node properties</p>
        </div>
        {selectedNode && (
          <Dialog open={showPythonCode} onOpenChange={setShowPythonCode}>
            <DialogTrigger asChild>
              <Button variant="outline" size="icon" className="flex-shrink-0 bg-transparent">
                <PythonIcon className="h-4 w-4" />
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-2xl">
              <DialogHeader>
                <div className="flex items-center justify-between">
                  <DialogTitle>Code Preview</DialogTitle>
                  <div className="flex items-center gap-2">
                    <Button
                      variant={codeViewMode === "python" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setCodeViewMode("python")}
                    >
                      <Code className="mr-2 h-4 w-4" />
                      Python
                    </Button>
                    <Button
                      variant={codeViewMode === "english" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setCodeViewMode("english")}
                    >
                      <Type className="mr-2 h-4 w-4" />
                      English
                    </Button>
                  </div>
                </div>
              </DialogHeader>
              <div className="py-4">
                {codeViewMode === "python" ? (
                  <div className="rounded-md bg-muted p-4 font-mono text-sm">
                    <pre className="text-foreground whitespace-pre-wrap">
                      {`# ${selectedNode.type.replace("-", " ").toUpperCase()} Node
# Reference: ${selectedNode.label || "N/A"}

def calculate_${selectedNode.type.replace("-", "_")}():
    """
    Calculate ${selectedNode.type.replace("-", " ")} amount
    """
    amount = ${selectedNode.amount}
    ${selectedNode.payTo ? `pay_to = "${selectedNode.payTo}"` : ""}
    ${selectedNode.due !== undefined ? `due = ${selectedNode.due}` : ""}
    
    # Process payment logic
    if amount > 0:
        return {
            "amount": amount,
            ${selectedNode.payTo ? `"pay_to": pay_to,` : ""}
            ${selectedNode.due !== undefined ? `"due": due,` : ""}
            "status": "processed"
        }
    return {"amount": 0, "status": "skipped"}`}
                    </pre>
                  </div>
                ) : (
                  <div className="rounded-md bg-muted/30 p-6">
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 mb-4">
                        <div className="h-2 w-2 rounded-full bg-primary" />
                        <span className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                          {selectedNode.type.replace("-", " ")}
                        </span>
                      </div>
                      <p className="text-sm leading-relaxed text-foreground">{getEnglishExplanation(selectedNode)}</p>
                      {selectedNode.label && (
                        <div className="mt-4 pt-4 border-t">
                          <div className="text-xs font-medium text-muted-foreground mb-2">Waterfall Reference</div>
                          <div className="text-sm font-mono bg-background px-3 py-2 rounded border">
                            {selectedNode.label}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-4 pb-8 scrollbar-thin scrollbar-thumb-muted scrollbar-track-transparent">
        {selectedNode ? (
          <div className="flex flex-col gap-4 pb-6">
            <Card className="p-4">
              <div className="flex flex-col gap-4">
                <div>
                  <Label className="text-sm font-medium text-card-foreground">Node Type</Label>
                  <p className="text-sm text-muted-foreground mt-1 capitalize">{selectedNode.type.replace("-", " ")}</p>
                </div>

                <div>
                  <Label htmlFor="waterfallRef" className="text-sm font-medium text-card-foreground">
                    Waterfall Section Reference
                  </Label>
                  <div className="flex gap-2 mt-1">
                    <Input
                      id="waterfallRef"
                      type="text"
                      value={selectedNode.label}
                      onChange={(e) => onUpdateLabel(selectedNode.id, e.target.value)}
                      placeholder="e.g., Section 1, Step A"
                      className="flex-1"
                    />
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="icon" className="flex-shrink-0 bg-transparent">
                          <FileText className="h-4 w-4" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-lg">
                        <DialogHeader>
                          <DialogTitle>Document Reference</DialogTitle>
                        </DialogHeader>
                        <div className="py-4">
                          <div className="rounded-md bg-muted p-4">
                            <p className="text-sm text-foreground leading-relaxed">
                              All amounts received from the Servicer for the related Distribution Date, excluding Advance Reversals and investment income, but including Recoveries.
                            </p>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>

                {selectedNode.due !== undefined && (
                  <div>
                    <Label htmlFor="due" className="text-sm font-medium text-card-foreground">
                      Due ($)
                    </Label>
                    <Input
                      id="due"
                      type="number"
                      value={selectedNode.due}
                      onChange={(e) => onUpdateDue(selectedNode.id, Number.parseFloat(e.target.value) || 0)}
                      className="mt-1"
                      placeholder="Enter due amount"
                    />
                  </div>
                )}

                {selectedNode.type === "interest-payment" && (
                  <Dialog open={calcOpen} onOpenChange={setCalcOpen}>
                    <DialogTrigger asChild>
                      <Button variant="outline" className="w-full bg-transparent">
                        <Calculator className="h-4 w-4 mr-2" />
                        See Interest Calc
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-md">
                      <DialogHeader>
                        <DialogTitle>Interest Calculation — {selectedNode.label}</DialogTitle>
                      </DialogHeader>
                      <div className="flex flex-col gap-4 py-4">
                        <div className="flex flex-col gap-2">
                          <Label htmlFor="balance">Balance ($)</Label>
                          <Input
                            id="balance"
                            type="number"
                            value={balance}
                            onChange={(e) => setBalance(e.target.value)}
                            placeholder="Enter balance"
                          />
                        </div>
                        <div className="flex flex-col gap-2">
                          <Label htmlFor="interestRate">Interest Rate (%)</Label>
                          <Input
                            id="interestRate"
                            type="number"
                            value={interestRate}
                            onChange={(e) => setInterestRate(e.target.value)}
                            placeholder="Enter interest rate"
                          />
                        </div>
                        <div className="flex flex-col gap-2">
                          <Label htmlFor="accrualDay">Accrual Days</Label>
                          <Input
                            id="accrualDay"
                            type="number"
                            value={accrualDay}
                            onChange={(e) => setAccrualDay(e.target.value)}
                            placeholder="e.g. 30"
                          />
                        </div>

                        {balance && interestRate && accrualDay && (
                          <div className="rounded-lg border bg-muted/40 p-4 space-y-2">
                            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Calculation Result</p>
                            <p className="text-sm font-mono text-foreground">
                              ${Number(balance).toLocaleString()} × {interestRate}% × {accrualDay}/360
                            </p>
                            <p className="text-xl font-bold text-primary">
                              = ${(
                                (Number(balance) * (Number(interestRate) / 100) * Number(accrualDay)) / 360
                              ).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </p>
                            {selectedNode.due !== undefined && (
                              <p className="text-xs text-muted-foreground pt-1 border-t">
                                Due this period: ${selectedNode.due.toLocaleString()}
                              </p>
                            )}
                          </div>
                        )}
                      </div>
                    </DialogContent>
                  </Dialog>
                )}

                <div>
                  <Label htmlFor="amount" className="text-sm font-medium text-card-foreground">
                    {selectedNode.type === "available-fund" || selectedNode.type === "remaining-fund"
                      ? "Amount ($)"
                      : "Paid ($)"}
                  </Label>
                  <Input
                    id="amount"
                    type="number"
                    value={selectedNode.amount}
                    onChange={(e) => onUpdateAmount(selectedNode.id, Number.parseFloat(e.target.value) || 0)}
                    className="mt-1"
                    placeholder="Enter amount"
                  />
                </div>

                {selectedNode.payTo !== undefined && (
                  <div>
                    <Label htmlFor="payTo" className="text-sm font-medium text-card-foreground">
                      Pay To
                    </Label>
                    <Input
                      id="payTo"
                      type="text"
                      value={selectedNode.payTo}
                      onChange={(e) => onUpdatePayTo(selectedNode.id, e.target.value)}
                      className="mt-1"
                      placeholder="e.g., Class A, Class B"
                    />
                  </div>
                )}

                <div>
                  <Label className="text-sm font-medium text-card-foreground">Connections</Label>
                  <p className="text-sm text-muted-foreground mt-1">
                    {selectedNode.connections.length} connected node(s)
                  </p>
                </div>
              </div>
            </Card>

            <Button variant="destructive" onClick={() => onDeleteNode(selectedNode.id)} className="w-full">
              <Trash2 className="h-4 w-4 mr-2" />
              Delete Node
            </Button>
          </div>
        ) : (
          <Card className="p-6 flex items-center justify-center min-h-[200px]">
            <p className="text-sm text-muted-foreground text-center">Select a node to view and edit its properties</p>
          </Card>
        )}
      </div>
    </div>
  )
}
