"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { AIChatPanel, AIChatButton } from "@/components/ai-chat-panel"
import { dealsData } from "@/lib/data"
import { Search, Plus, MoreVertical, Eye, Edit, Trash2 } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export default function DashboardPage() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [isAIChatOpen, setIsAIChatOpen] = useState(false)

  const filteredDeals = dealsData.deals.filter(
    (deal) =>
      deal.deal_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      deal.asset_type.toLowerCase().includes(searchQuery.toLowerCase()) ||
      deal.analyst.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "active":
        return "default"
      case "pending":
        return "secondary"
      case "archived":
        return "outline"
      default:
        return "default"
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <AIChatPanel isOpen={isAIChatOpen} onClose={() => setIsAIChatOpen(false)} />

      <div
        className="transition-all duration-300 ease-out"
        style={{ marginRight: isAIChatOpen ? "420px" : "0" }}
      >

      {/* Top Navigation */}
      <header className="sticky top-0 z-50 border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="flex h-16 items-center gap-4 px-6">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <svg className="h-5 w-5 text-primary-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                />
              </svg>
            </div>
            <span className="text-lg font-semibold">StructuredAI</span>
          </div>

          <nav className="ml-8 flex gap-6">
            <Button variant="ghost" className="text-sm font-medium" onClick={() => router.push("/dashboard")}>
              Dashboard
            </Button>
            <Button variant="ghost" className="text-sm font-medium text-muted-foreground" onClick={() => router.push("/dashboard")}>
              Deals
            </Button>
            <Button variant="ghost" className="text-sm font-medium text-muted-foreground" disabled>
              Model
            </Button>
            <Button variant="ghost" className="text-sm font-medium text-muted-foreground" disabled>
              Reports
            </Button>
            <Button variant="ghost" className="text-sm font-medium text-muted-foreground" disabled>
              Simulations
            </Button>
          </nav>

          <div className="ml-auto flex items-center gap-2">
            <AIChatButton onClick={() => setIsAIChatOpen(true)} />
            <Button variant="outline" size="sm">
              Sign Out
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        <div className="mx-auto max-w-7xl space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Deal Dashboard</h1>
              <p className="text-muted-foreground">Manage and analyze your structured finance transactions</p>
            </div>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              New Deal
            </Button>
          </div>

          {/* Search and Filters */}
          <div className="flex items-center gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search deals by ID, asset type, or analyst..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          {/* Deals Table */}
          <div className="rounded-lg border bg-card">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Deal Name</TableHead>
                  <TableHead>Asset Type</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Analyst</TableHead>
                  <TableHead>Last Updated</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDeals.map((deal) => (
                  <TableRow key={deal.deal_id} className="cursor-pointer hover:bg-muted/50" onClick={() => router.push(`/deal/${deal.deal_id}`)}>
                    <TableCell className="font-medium">{deal.deal_id}</TableCell>
                    <TableCell>{deal.asset_type}</TableCell>
                    <TableCell>
                      <Badge variant={getStatusColor(deal.status)}>{deal.status}</Badge>
                    </TableCell>
                    <TableCell>{deal.analyst}</TableCell>
                    <TableCell className="text-muted-foreground">{deal.last_updated}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreVertical className="h-4 w-4" />
                            <span className="sr-only">Open menu</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => router.push(`/deal/${deal.deal_id}`)}>
                            <Eye className="mr-2 h-4 w-4" />
                            View
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Edit className="mr-2 h-4 w-4" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive">
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* Stats Cards */}
          <div className="grid gap-4 md:grid-cols-3">
            <div className="rounded-lg border bg-card p-6">
              <div className="text-sm font-medium text-muted-foreground">Total Deals</div>
              <div className="mt-2 text-3xl font-bold">{dealsData.deals.length}</div>
              <div className="mt-1 text-xs text-muted-foreground">Across all asset types</div>
            </div>
            <div className="rounded-lg border bg-card p-6">
              <div className="text-sm font-medium text-muted-foreground">Active Models</div>
              <div className="mt-2 text-3xl font-bold">
                {dealsData.deals.filter((d) => d.status === "Active").length}
              </div>
              <div className="mt-1 text-xs text-muted-foreground">Currently processing</div>
            </div>
            <div className="rounded-lg border bg-card p-6">
              <div className="text-sm font-medium text-muted-foreground">Documents Parsed</div>
              <div className="mt-2 text-3xl font-bold">
                {dealsData.deals.reduce((acc, deal) => acc + deal.documents.length, 0)}
              </div>
              <div className="mt-1 text-xs text-muted-foreground">Legal documents analyzed</div>
            </div>
          </div>
        </div>
      </main>
      </div>
    </div>
  )
}
