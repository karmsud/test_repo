import { DealWorkspace } from "@/components/deal/deal-workspace"
import { dealsData } from "@/lib/data"
import { notFound } from "next/navigation"

export default async function DealPage({ params }: { params: Promise<{ dealId: string }> }) {
  const { dealId } = await params

  const deal = dealsData.deals.find((d) => d.deal_id === dealId)

  if (!deal) {
    notFound()
  }

  return <DealWorkspace deal={deal} />
}
