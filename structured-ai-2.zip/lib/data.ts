export const dealsData = {
  meta: {
    title: "Structured Finance AI Prototype – Fake Data Pack",
    version: "1.0.0",
    generated_at: "2025-10-28 16:46:13.620487Z",
    notes: [
      "This dataset is synthetic and designed for UI prototyping only.",
      "All numbers, clauses, and references are fictional but realistic.",
      "Intended to pre-populate v0.dev screens and simulate interactions end-to-end.",
    ],
  },
  ui: {
    feature_flags: {
      dark_mode: true,
      dual_view_toggle: true,
      hover_tooltips: true,
      drag_split_panes: true,
      fake_progress_bars: true,
      export_buttons: true,
      explain_this_month: true,
    },
    navigation: ["Dashboard", "Deals", "Model", "Reports", "Simulations"],
  },
  deals: [
    {
      deal_id: "2023-ABS1",
      asset_type: "Auto ABS",
      status: "Active",
      analyst: "Analyst A",
      last_updated: "2025-09-15",
      documents: [
        {
          name: "Trust & Servicing Agreement.pdf",
          type: "Legal Doc",
          pages: 180,
          status: "Parsed",
          sections: {
            definitions: ["§1.01"],
            priority_of_payments: ["§4.01(a)-(f)"],
            tests: ["§5.03(a)-(c)"],
            reporting: ["§7.02(a)"],
          },
        },
        {
          name: "Prospectus Supplement.pdf",
          type: "Legal Doc",
          pages: 120,
          status: "Parsed",
          sections: {
            definitions: ["§1.02"],
            accounts: ["§2.09"],
            reporting: ["§6.01"],
          },
        },
        {
          name: "Indenture.pdf",
          type: "Legal Doc",
          pages: 240,
          status: "Parsed",
          sections: {
            definitions: ["§1.01"],
            interest: ["§4.02-§4.03"],
            principal: ["§4.04"],
            tests: ["§5.04(b)"],
          },
        },
      ],
      definitions: [
        {
          id: "def_available_funds",
          term: "Available Funds",
          text: "All amounts received from the Servicer for the related Distribution Date, excluding advances reversals and investment income, but including recoveries.",
          source_doc: "Trust & Servicing Agreement.pdf",
          section: "§1.01",
        },
        {
          id: "def_oc_ratio",
          term: "OC Ratio",
          text: "(Collateral Balance – Subordinate Notes) / Collateral Balance.",
          source_doc: "Indenture.pdf",
          section: "§5.03",
        },
        {
          id: "def_reserve_account",
          term: "Reserve Account",
          text: "An account funded to maintain a balance equal to 0.50% of the Pool Balance at BOP, subject to a floor of $100,000.",
          source_doc: "Prospectus Supplement.pdf",
          section: "§2.09",
        },
        {
          id: "def_servicer",
          term: "Servicer",
          text: "AI Hackathon Servicing, LLC.",
          source_doc: "Trust & Servicing Agreement.pdf",
          section: "§1.01",
        },
        {
          id: "def_distribution_date",
          term: "Distribution Date",
          text: "The 25th day of each calendar month, or if such 25th day is not a Business Day...",
          source_doc: "Trust & Servicing Agreement.pdf",
          section: "§1.01",
        },
        {
          id: "def_business_day",
          term: "Business Day",
          text: "Any day other than a Saturday, Sunday, or a day on which banking institutions...",
          source_doc: "Trust & Servicing Agreement.pdf",
          section: "§1.01",
        },
        {
          id: "def_closing_date",
          term: "Closing Date",
          text: "January 2, 2026.",
          source_doc: "Trust & Servicing Agreement.pdf",
          section: "§1.01",
        },
        {
          id: "def_advance_reversals",
          term: "Advance Reversals",
          text: "Any amounts that were previously advanced by the Servicer and are subsequently...",
          source_doc: "Trust & Servicing Agreement.pdf",
          section: "§1.01",
        },
        {
          id: "def_master_servicer",
          term: "Master Servicer",
          text: "AI Hackathon Master Servicing Corp., a Delaware corporation.",
          source_doc: "Trust & Servicing Agreement.pdf",
          section: "§1.01",
        },
        {
          id: "def_recoveries",
          term: "Recoveries",
          text: "All amounts collected on Defaulted Loans after the applicable Charge-Off Date...",
          source_doc: "Trust & Servicing Agreement.pdf",
          section: "§3.05",
        },
        {
          id: "def_defaulted_loans",
          term: "Defaulted Loans",
          text: "Any Mortgage Loan that has become 180 or more days delinquent or has been...",
          source_doc: "Trust & Servicing Agreement.pdf",
          section: "§1.01",
        },
        {
          id: "def_mortgage_loan",
          term: "Mortgage Loan",
          text: "Each residential mortgage loan transferred and assigned to the Issuing Entity...",
          source_doc: "Trust & Servicing Agreement.pdf",
          section: "§1.01",
        },
        {
          id: "def_issuing_entity",
          term: "Issuing Entity",
          text: "AI Hackathon 2026-1 Trust, a Delaware statutory trust.",
          source_doc: "Trust & Servicing Agreement.pdf",
          section: "§1.01",
        },
        {
          id: "def_trust_agreement",
          term: "Trust Agreement",
          text: "The agreement dated as of the Closing Date among the Depositor, the Issuing...",
          source_doc: "Indenture.pdf",
          section: "§1.01",
        },
        {
          id: "def_depositor",
          term: "Depositor",
          text: "AI Hackathon Depositor, LLC, a Delaware limited liability company.",
          source_doc: "Prospectus Supplement.pdf",
          section: "§3.01",
        },
        {
          id: "def_indenture_trustee",
          term: "Indenture Trustee",
          text: "U.S. Bank National Association, a national banking association.",
          source_doc: "Indenture.pdf",
          section: "§1.01",
        },
        {
          id: "def_charge_off_date",
          term: "Charge-Off Date",
          text: "The date on which a Mortgage Loan is classified as a Defaulted Loan by the...",
          source_doc: "Trust & Servicing Agreement.pdf",
          section: "§4.02",
        },
      ],
      fees: [
        {
          name: "Servicer Fee",
          basis: "pool_balance_bop",
          rate_apy: 0.005,
          source_doc: "Trust & Servicing Agreement.pdf",
          section: "§4.01(a)",
        },
        {
          name: "Trustee Fee",
          flat_per_period: 2000,
          source_doc: "Trust & Servicing Agreement.pdf",
          section: "§4.01(b)",
        },
      ],
      accounts: [
        {
          name: "Reserve",
          target: "0.005 * pool_balance_bop",
          floor: 100000,
          source_doc: "Prospectus Supplement.pdf",
          section: "§2.09",
        },
      ],
      classes: [
        {
          name: "ClassA",
          rate_index: "SOFR_1M",
          spread_bps: 120,
          accrual: "ACT/360",
          balance_bop: 8000000.0,
        },
        {
          name: "ClassB",
          rate_index: "SOFR_1M",
          spread_bps: 200,
          accrual: "ACT/360",
          balance_bop: 4000000.0,
        },
      ],
      tests: [
        {
          name: "OC_Test",
          type: "ratio",
          formula: "(collateral_balance - subordinate_balance) / collateral_balance",
          threshold: 0.03,
          breach_condition: "< 0.03",
          source_refs: [
            {
              doc: "Indenture.pdf",
              section: "§5.04(b)",
              excerpt: "If OC Ratio is less than 3.00%, principal shall be applied sequentially.",
            },
            {
              doc: "Indenture.pdf",
              section: "§1.01",
              excerpt: "Definition of OC Ratio.",
            },
          ],
        },
      ],
      waterfalls: [
        {
          name: "InterestWaterfall",
          source: "AvailableFunds + Reserve.release",
          steps: [
            {
              step: 1,
              action: "pay_fee",
              target: "Servicer Fee",
              source_refs: [
                {
                  doc: "Trust & Servicing Agreement.pdf",
                  section: "§4.01(a)",
                },
              ],
            },
            {
              step: 2,
              action: "pay_fee",
              target: "Trustee Fee",
              source_refs: [
                {
                  doc: "Trust & Servicing Agreement.pdf",
                  section: "§4.01(b)",
                },
              ],
            },
            {
              step: 3,
              action: "pay_interest",
              target: "ClassA",
              source_refs: [
                {
                  doc: "Indenture.pdf",
                  section: "§4.02",
                },
              ],
            },
            {
              step: 4,
              action: "pay_interest",
              target: "ClassB",
              source_refs: [
                {
                  doc: "Indenture.pdf",
                  section: "§4.03",
                },
              ],
            },
            {
              step: 5,
              action: "top_up_reserve",
              target: "Reserve",
              source_refs: [
                {
                  doc: "Prospectus Supplement.pdf",
                  section: "§2.09",
                },
              ],
            },
            {
              step: 6,
              action: "residual",
              target: "Equity",
              source_refs: [
                {
                  doc: "Trust & Servicing Agreement.pdf",
                  section: "§4.01(f)",
                },
              ],
            },
          ],
        },
        {
          name: "PrincipalWaterfall",
          source: "PrincipalCollections + Recoveries",
          mode_switch: {
            condition_python: "OC_ratio < 1.03",
            condition_english: "If OC Ratio falls below 1.03, switch to sequential principal.",
            source_refs: [
              {
                doc: "Indenture.pdf",
                section: "§5.04(b)",
              },
            ],
          },
          steps_if_sequential: [
            {
              step: 1,
              action: "pay_principal",
              target: "ClassA",
            },
            {
              step: 2,
              action: "pay_principal",
              target: "ClassB",
            },
            {
              step: 3,
              action: "residual",
              target: "Equity",
            },
          ],
          steps_if_pro_rata: [
            {
              step: 1,
              action: "pay_principal_prorata",
              targets: ["ClassA", "ClassB"],
            },
            {
              step: 2,
              action: "residual",
              target: "Equity",
            },
          ],
        },
      ],
      python_model: `# Simplified generated model (demo-only)
from decimal import Decimal

def accrue_interest(balance_bop, index_rate, spread_bps, days, basis='ACT/360'):
    rate = Decimal(index_rate) + Decimal(spread_bps)/Decimal(10000)
    denom = Decimal(360 if basis=='ACT/360' else 365)
    return (Decimal(balance_bop) * rate * Decimal(days) / denom).quantize(Decimal('0.01'))

def run_interest_waterfall(state):
    cash = state['available_funds'] + state['reserve_release']
    cash -= state['fees']['servicer']
    cash -= state['fees']['trustee']
    payA = min(cash, state['interest_due']['ClassA']); cash -= payA
    payB = min(cash, state['interest_due']['ClassB']); cash -= payB
    # Top up reserve to target
    top_up = max(Decimal('0'), state['reserve_target'] - state['reserve_balance'])
    add = min(cash, top_up); cash -= add; state['reserve_balance'] += add
    state['residual_interest'] = cash; cash = Decimal('0')
    return state

def run_principal_waterfall(state):
    cash = state['principal_collections'] + state['recoveries']
    if state['OC_ratio'] < Decimal('1.03'):
        # sequential
        payA = min(cash, state['balances']['ClassA']); cash -= payA; state['principal_paid']['ClassA'] = payA
        payB = min(cash, state['balances']['ClassB']); cash -= payB; state['principal_paid']['ClassB'] = payB
    else:
        total = state['balances']['ClassA'] + state['balances']['ClassB']
        for k in ['ClassA','ClassB']:
            share = cash * state['balances'][k] / total
            paid = min(share, state['balances'][k]); state['principal_paid'][k] = paid
        cash = Decimal('0')
    state['residual_principal'] = cash
    return state
`,
      english_rules: [
        {
          rule_id: "r_interest_order",
          english:
            "Apply available funds in this order: Servicer Fee, Trustee Fee, interest for Class A then Class B, top up Reserve to target, remainder to Equity.",
          python_hint: "run_interest_waterfall",
        },
        {
          rule_id: "r_principal_switch",
          english: "If OC Ratio is below 1.03, pay principal sequentially A→B; otherwise pay A and B pro‑rata.",
          python_hint: "run_principal_waterfall",
        },
      ],
      rule_references: [
        {
          rule_id: "r_interest_order",
          sources: [
            {
              doc: "Trust & Servicing Agreement.pdf",
              section: "§4.01(a)-(f)",
              excerpt:
                "Available Funds shall be applied: first to Servicer Fee; second to Trustee Fee; third to Class A Interest; fourth to Class B Interest; fifth to Reserve top-up; thereafter to Residual.",
            },
            {
              doc: "Prospectus Supplement.pdf",
              section: "§2.09",
              excerpt: "Reserve Account target equals 0.50% of Pool Balance, floor $100,000.",
            },
          ],
        },
        {
          rule_id: "r_principal_switch",
          sources: [
            {
              doc: "Indenture.pdf",
              section: "§5.04(b)",
              excerpt: "Upon an OC Ratio breach, principal shall be applied sequentially until the breach is cured.",
            },
            {
              doc: "Indenture.pdf",
              section: "§1.01",
              excerpt: "OC Ratio: (Collateral Balance − Subordinate Notes) / Collateral Balance.",
            },
          ],
        },
      ],
      report_schema: {
        sections: [
          {
            header: "Class Detail",
            rows: [
              {
                label: "ClassA Interest Due",
                expr: "interest_due.ClassA",
              },
              {
                label: "ClassA Interest Paid",
                expr: "interest_paid.ClassA",
              },
              {
                label: "ClassA Interest Shortfall",
                expr: "interest_shortfall.ClassA",
              },
              {
                label: "ClassA Principal Paid",
                expr: "principal_paid.ClassA",
              },
              {
                label: "ClassA Balance EOP",
                expr: "balances_eop.ClassA",
              },
            ],
          },
          {
            header: "Coverage Tests",
            rows: [
              {
                label: "OC Ratio",
                expr: "OC_ratio",
                pass_fail: ">= 1.03",
              },
            ],
          },
          {
            header: "Accounts",
            rows: [
              {
                label: "Reserve EOP",
                expr: "reserve_balance_eop",
              },
            ],
          },
        ],
      },
      reports: [
        {
          period: "2025-08-25",
          classes: [
            {
              name: "ClassA",
              interest_due: 150000,
              interest_paid: 150000,
              principal_paid: 250000,
              balance_eop: 7750000,
            },
            {
              name: "ClassB",
              interest_due: 80000,
              interest_paid: 80000,
              principal_paid: 120000,
              balance_eop: 3880000,
            },
          ],
          tests: [
            {
              name: "OC Ratio",
              value: 1.03,
              pass: true,
            },
          ],
          accounts: {
            reserve_eop: 100000,
          },
          narrative: "OC Ratio at threshold; principal distributed pro‑rata per §5.04(b).",
        },
      ],
      servicer_tape_sample: [
        {
          loan_id: "L001",
          bop_balance: 12000,
          rate_type: "Fixed",
          index: null,
          spread_bps: 0,
          current_rate: 0.079,
          days_in_period: 30,
          status: "Current",
          prin_collect: 300,
          int_collect: 79,
          recoveries: 0,
          loss: 0,
        },
        {
          loan_id: "L002",
          bop_balance: 15000,
          rate_type: "Floating",
          index: "SOFR_1M",
          spread_bps: 450,
          current_rate: 0.084,
          days_in_period: 30,
          status: "30DPD",
          prin_collect: 0,
          int_collect: 0,
          recoveries: 50,
          loss: 20,
        },
      ],
      simulation_defaults: {
        cpr: 0.08,
        cdr: 0.03,
        severity: 0.35,
        recovery_lag_months: 3,
        advance_rate: 0.8,
      },
    },
    {
      deal_id: "2024-CMBS5",
      asset_type: "CMBS",
      status: "Active",
      analyst: "Analyst B",
      last_updated: "2025-09-10",
      documents: [
        {
          name: "Pooling & Servicing Agreement.pdf",
          type: "Legal Doc",
          pages: 210,
          status: "Parsed",
        },
        {
          name: "Prospectus Supplement.pdf",
          type: "Legal Doc",
          pages: 150,
          status: "Parsed",
        },
      ],
      definitions: [
        {
          id: "def_ncf",
          term: "Net Cash Flow",
          text: "Property NOI less capex reserves and fees.",
          source_doc: "Pooling & Servicing Agreement.pdf",
          section: "§1.01",
        },
        {
          id: "def_appraisal_reduction",
          term: "Appraisal Reduction Amount",
          text: "Amount reducing distributions to rated classes upon appraisal reduction event.",
          source_doc: "Pooling & Servicing Agreement.pdf",
          section: "§6.02",
        },
      ],
      fees: [
        {
          name: "Master Servicer Fee",
          basis: "pool_balance_bop",
          rate_apy: 0.0025,
          source_doc: "Pooling & Servicing Agreement.pdf",
          section: "§3.02",
        },
        {
          name: "Special Servicer Fee",
          basis: "specially_serviced_balance",
          rate_apy: 0.01,
          source_doc: "Pooling & Servicing Agreement.pdf",
          section: "§3.03",
        },
      ],
      accounts: [
        {
          name: "Liquidity Reserve",
          target: "0.01 * pool_balance_bop",
          floor: 500000,
          source_doc: "Prospectus Supplement.pdf",
          section: "§2.12",
        },
      ],
      classes: [
        {
          name: "ClassA",
          rate_index: "SOFR_1M",
          spread_bps: 95,
          accrual: "ACT/360",
          balance_bop: 150000000.0,
        },
        {
          name: "ClassB",
          rate_index: "SOFR_1M",
          spread_bps: 160,
          accrual: "ACT/360",
          balance_bop: 30000000.0,
        },
        {
          name: "ClassC",
          rate_index: "SOFR_1M",
          spread_bps: 300,
          accrual: "ACT/360",
          balance_bop: 15000000.0,
        },
      ],
      tests: [
        {
          name: "Appraisal Reduction Trigger",
          type: "event",
          formula: "if appraisal_reduction_event: divert_interest_to_senior",
          threshold: null,
          source_refs: [
            {
              doc: "Pooling & Servicing Agreement.pdf",
              section: "§6.02",
              excerpt: "Upon Appraisal Reduction Event, interest to subordinate classes is diverted to senior classes.",
            },
          ],
        },
      ],
      waterfalls: [
        {
          name: "InterestWaterfall",
          source: "AvailableFunds + LiquidityReserve.release",
          steps: [
            {
              step: 1,
              action: "pay_fee",
              target: "Master Servicer Fee",
            },
            {
              step: 2,
              action: "pay_fee",
              target: "Special Servicer Fee",
            },
            {
              step: 3,
              action: "pay_interest",
              target: "ClassA",
            },
            {
              step: 4,
              action: "pay_interest",
              target: "ClassB",
            },
            {
              step: 5,
              action: "pay_interest",
              target: "ClassC",
            },
            {
              step: 6,
              action: "top_up_reserve",
              target: "Liquidity Reserve",
            },
            {
              step: 7,
              action: "residual",
              target: "Equity",
            },
          ],
        },
        {
          name: "PrincipalWaterfall",
          source: "PrincipalCollections + Recoveries",
          mode_switch: {
            condition_python: "appraisal_reduction_event == True",
            condition_english:
              "During an Appraisal Reduction Event, principal remains sequential regardless of OC status.",
            source_refs: [
              {
                doc: "Pooling & Servicing Agreement.pdf",
                section: "§6.02",
              },
            ],
          },
          steps_if_sequential: [
            {
              step: 1,
              action: "pay_principal",
              target: "ClassA",
            },
            {
              step: 2,
              action: "pay_principal",
              target: "ClassB",
            },
            {
              step: 3,
              action: "pay_principal",
              target: "ClassC",
            },
            {
              step: 4,
              action: "residual",
              target: "Equity",
            },
          ],
          steps_if_pro_rata: [
            {
              step: 1,
              action: "pay_principal_prorata",
              targets: ["ClassA", "ClassB", "ClassC"],
            },
            {
              step: 2,
              action: "residual",
              target: "Equity",
            },
          ],
        },
      ],
      reports: [
        {
          period: "2025-08-25",
          classes: [
            {
              name: "ClassA",
              interest_due: 950000,
              interest_paid: 950000,
              principal_paid: 2500000,
              balance_eop: 147500000,
            },
            {
              name: "ClassB",
              interest_due: 400000,
              interest_paid: 400000,
              principal_paid: 500000,
              balance_eop: 29500000,
            },
            {
              name: "ClassC",
              interest_due: 375000,
              interest_paid: 300000,
              principal_paid: 0,
              balance_eop: 15000000,
            },
          ],
          tests: [
            {
              name: "Appraisal Reduction Event",
              value: false,
              pass: true,
            },
          ],
          accounts: {
            liquidity_reserve_eop: 500000,
          },
          narrative: "Normal period; no appraisal reduction. Pro‑rata principal applied.",
        },
      ],
      simulation_defaults: {
        cpr: 0.06,
        cdr: 0.02,
        severity: 0.4,
        recovery_lag_months: 6,
        advance_rate: 0.75,
      },
    },
    {
      deal_id: "2022-MBS3",
      asset_type: "MBS",
      status: "Active",
      analyst: "Analyst A",
      last_updated: "2025-08-20",
      documents: [],
      definitions: [],
      fees: [],
      accounts: [],
      classes: [],
      tests: [],
      waterfalls: [],
      reports: [],
    },
  ],
} as const

export type Deal = (typeof dealsData.deals)[number]
