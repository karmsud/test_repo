# Definition of Done by Gate (Agentic SDLC)

This checklist is designed to be **bank-grade**: it prioritizes traceability, security, and evidence.

---

## Gate 0 — Story Readiness (Jira)
**Required**
- [ ] Problem statement and business outcome
- [ ] Scope and out-of-scope
- [ ] Acceptance criteria (AC) present (bullets or Gherkin)
- [ ] Data classification tag: PII / PCI / Internal / Public
- [ ] Logging requirements (what must be logged; what must be redacted)
- [ ] Threat model tag: None / Light / Required
- [ ] Dependencies listed (systems/teams/config)
- [ ] Test intent defined: unit / integration / acceptance
- [ ] Rollback strategy (high level)

**Agent outputs**
- AC gaps flagged + suggested scenarios
- Negative cases and edge cases proposed
- Risk flags (auth/data changes, migrations, AI features)

---

## Gate 1 — Spec & Design Approval (Repo + Confluence)
**Required**
- [ ] Structured specs committed (SpecDD)
  - [ ] API specs (OpenAPI/JSON Schema) if relevant
  - [ ] Rules decision tables if relevant
  - [ ] NFR spec (rate limits, retries, timeouts)
  - [ ] UI flows (Gherkin + page mapping) if relevant
- [ ] Confluence summary posted (derived from specs)
- [ ] Architecture impacts documented (ADR if needed)
- [ ] Security posture documented (auth boundaries, least privilege)
- [ ] Approvals captured: Product + Tech Lead (+ Security if flagged)

**Agent outputs**
- Design summary, sequence/flow notes, failure modes
- Trace links: Jira ↔ spec files ↔ Confluence

---

## Gate 2 — Build Quality (PR)
**Required**
- [ ] Code compiles/builds
- [ ] Lint/format passes
- [ ] Unit tests pass
- [ ] Static analysis passes (as configured)
- [ ] SAST + dependency scans pass
- [ ] Coverage delta meets policy
- [ ] PR includes traceability (Jira key, spec references)

**Agent outputs**
- PR description includes “what/why/how/test”
- Updated specs/docs aligned with code changes

---

## Gate 3 — Acceptance & Evidence (CI + Playwright)
**Required**
- [ ] Acceptance suite green (API and/or UI)
- [ ] E2E tests (Playwright) updated/created for critical paths when applicable
- [ ] Evidence attached:
  - [ ] Test reports
  - [ ] Screenshots/videos (UI)
  - [ ] Logs with redaction
- [ ] Flaky tests flagged (no silent healing without review)
- [ ] Regression suite selection recorded

**Agent outputs**
- Evidence pack links posted to PR and Confluence sprint page
- Failure analysis if tests fail

---

## Gate 4 — Governance & Release Readiness
**Required**
- [ ] AI Production Check passes (if AI-tagged)
- [ ] Audit packet generated (traceability + evidence)
- [ ] Rollback plan included in release notes
- [ ] Release notes generated and approved
- [ ] Master reviewer sign-off complete
- [ ] Deployment approvals per change control

**Agent outputs**
- Audit packet: Jira → commits → tests → evidence → approvals
- Release notes and operational notes (monitoring, alerting)
