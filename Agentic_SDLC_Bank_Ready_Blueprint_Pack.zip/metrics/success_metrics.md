# Success Metrics (Pilot)

## Cycle time
- Median time from Gate 0 → Gate 4 for 2-day candidates
- Time spent waiting for approvals (Gate 1 and Gate 4)

## Quality
- Defects found post-merge (30-day window)
- Escaped defects severity (P0/P1/P2)
- Test coverage delta and meaningfulness checks

## Reliability of automation
- Flaky test rate (acceptance/E2E)
- Agent rework rate (number of iterations per PR)

## Compliance/auditability
- % of changes with complete traceability matrix
- Evidence packet completeness rate

## Developer & reviewer experience
- Reviewer time per PR
- Number of PRs per engineer per day (sustainable throughput)
