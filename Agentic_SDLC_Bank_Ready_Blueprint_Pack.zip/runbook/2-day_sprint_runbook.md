# Runbook: 2-Day Agentic Sprint Execution

## Preconditions (non-negotiable for 2-day target)
- Stable CI and environments
- Baseline test scaffolding exists
- Jira stories meet Gate 0
- Confluence templates in place
- Branch naming and PR conventions standardized

---

## Day 1 (AM) — Intake → Spec → Gate 1
1. Run `/harvest_sprint`
2. Resolve missing AC/data tags; apply `ready:agent`
3. Run `/generate_specs`
4. Approve Gate 1 (Product + Tech Lead; Security if flagged)

**Deliverables**
- Sprint Pack page in Confluence
- Spec artifacts committed

---

## Day 1 (PM) — Build → Gate 2
1. For each story, run:
   - `/plan_implementation`
   - `/tdd_unit_tests`
   - `/implement_story`
2. Ensure Gate 2 passes (CI green)

**Deliverables**
- PRs open with traceability links
- Unit tests and specs updated

---

## Day 2 (AM) — Acceptance + evidence → Gate 3
1. Run `/acceptance_add_suite`
2. Run `/playwright_e2e` (UI changes)
3. Fix failures; flag flakes explicitly

**Deliverables**
- Acceptance suite green
- Evidence attached (reports/screenshots/logs)

---

## Day 2 (PM) — Governance + release readiness → Gate 4
1. For AI stories, run `/ai_production_check`
2. Run `/evidence_and_release_pack`
3. Master reviewer sign-off
4. Merge/deploy per change control

**Deliverables**
- Audit packet complete
- Release notes posted
