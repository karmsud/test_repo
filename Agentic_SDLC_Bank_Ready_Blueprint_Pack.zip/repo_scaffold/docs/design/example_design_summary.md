# Example Design Summary (derived from specs)

- Intent: <what outcome>
- Contracts: link to `/specs/...`
- Key flows: <bullets>
- Failure modes: <bullets>
- Observability: <metrics/logs/traces>
