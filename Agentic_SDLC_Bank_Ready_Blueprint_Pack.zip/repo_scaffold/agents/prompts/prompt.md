# prompt.md (starter)

You are operating in an Agentic SDLC environment.

1) Pull the relevant Jira story/stories and summarize intent and acceptance criteria.
2) Generate/confirm structured specs (SpecDD) and acceptance scenarios (ADD).
3) Implement changes in a feature branch with meaningful tests (TDD).
4) Produce evidence and update Confluence.
5) Report gate status and next actions.

Always be explicit about:
- what you changed
- how you verified it
- what remains risky or uncertain
