# copilot-instructions.md (starter)

## Coding standards
- Prefer small, reversible commits.
- Respect existing architecture boundaries.
- Add tests for every behavior change (unit first where possible).
- Keep docs thin; specs are the source of truth.

## Security & compliance
- Never write secrets to the repo. Use approved secret stores.
- Redact PII/PCI in logs and artifacts.
- Enforce least privilege for auth scopes/permissions.
- For AI features: apply AI Production Check controls.

## Traceability
- Include Jira key in branch, commits, and PR title/description.
- Update SpecDD artifacts when behavior changes.
- Ensure acceptance scenarios map to Jira keys.

## Evidence
- For UI changes, update Playwright tests and capture evidence artifacts.
- Attach test reports/evidence to PR and Confluence sprint pack.

## Gate discipline
- Do not request merge. Provide a Gate status checklist in the PR description.
