# agents.md (starter)

## Agent Charter
Agents may:
- Read repo, specs, tests, docs
- Create branches, commits, PRs
- Generate/update specs and tests
- Post summaries to Confluence and update Jira (via MCP)

Agents may NOT:
- Merge PRs
- Modify production config directly
- Bypass security controls, redaction, or approvals

## Required outputs (every run)
- Actions taken
- Files changed (paths)
- Links created/updated (Jira/Confluence/PR)
- Gate status summary
- Risks and follow-ups

## Tools (MCP)
- Jira MCP: query/update issues
- Confluence MCP: create/update pages
- GitHub MCP: repo/PR operations
- Playwright MCP: UI automation evidence
