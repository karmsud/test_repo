# Repo Scaffold: Agentic SDLC Starter Kit

This scaffold supports:
- SpecDD (structured specs)
- TDD (unit tests)
- ADD (acceptance tests)
- Agent-driven evidence + release packaging

## Directory layout
- `/specs` — source-of-truth contracts
- `/tests` — unit/integration/acceptance
- `/docs` — thin summaries + ADRs
- `/agents` — Copilot agent instructions and prompts

## Adoption steps
1. Copy this scaffold into the repo.
2. Align CI to enforce Gates 2–4.
3. Start with the 7-agent MVP workflow.
