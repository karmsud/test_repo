Feature: Example acceptance

  # Traceability: JIRA-1234
  Scenario: Happy path example
    Given the user is authenticated
    When the user performs the primary action
    Then the system returns success
