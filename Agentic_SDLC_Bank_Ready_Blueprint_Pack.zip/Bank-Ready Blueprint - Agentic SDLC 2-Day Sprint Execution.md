# Bank-Ready Blueprint: Agentic SDLC for 2-Day Sprint Execution

**Date:** February 22, 2026  
**Audience:** Product, Engineering, Architecture, Security, Risk/Compliance, DevEx/Platform  
**Scope:** VS Code + Copilot Agents + MCP (Jira/Confluence/GitHub/Playwright) in a regulated banking environment

---

## 1. Executive intent

**Goal:** Convert eligible “2-week sprint” work into a **2-day delivery cycle** by shifting humans to **decision + approval gates** and delegating repeatable execution to **tool-using agents** (docs, code, tests, evidence).

**Core principle:** **Gated autonomy**  
Agents may generate and modify artifacts (code, tests, docs) but **cannot merge or release** unless gates pass and human approvals are recorded.

**Expected outcomes**
- Faster cycle time for eligible work (often 3–10×)
- Higher consistency in documentation, testing, and traceability
- Stronger auditability (evidence packets assembled automatically)
- Reduced rework via earlier executable acceptance criteria

---

## 2. Operating model

### 2.1 Work classification rubric (2-day vs. not)

**2-Day Candidate**
- Self-contained story within one bounded component/service
- Clear acceptance criteria (AC) + data classification tags
- Existing test scaffolding and stable CI
- No cross-team approval dependency beyond normal code review

**Not 2-Day (still supported; expect longer)**
- New/changed authn/authz model or entitlements redesign
- Data migrations with high blast radius / customer impact
- Ambiguous requirements / discovery-heavy scope
- Multi-system coordination (3+ teams)
- Legacy modules with weak tests (first sprint should build characterization tests)

**Policy:** Even “not 2-day” work uses the same pipeline; cadence extends because of approvals, dependencies, or risk controls—not because the workflow changes.

---

## 3. Artifact strategy: SpecDD + TDD + ADD (the contract layer)

### 3.1 SpecDD (source of truth)
Create **structured, diffable, enforceable specs**. Examples:
- **API:** OpenAPI + JSON Schema
- **Domain rules:** decision tables (YAML/JSON)
- **UI flows:** Gherkin features + page model mapping
- **NFRs:** NFR spec (YAML) for latency, retries, rate limits, logging, retention

**Rule:** prose docs must be derived from specs; specs are the source of truth.

### 3.2 TDD (fast correctness)
- Unit tests created first where feasible (or characterization tests for legacy)
- Coverage/quality policies enforced in CI
- Guard against “vacuous tests” (asserting nothing meaningful)

### 3.3 ADD (auditable acceptance)
- AC becomes **executable** (Gherkin or equivalent)
- Acceptance tests run in CI (API and/or UI E2E)
- Evidence pack generated automatically (logs/screenshots/videos/reports)

---

## 4. SDLC workflow: 5 gates (bank-friendly)

### Gate 0 — Story Readiness (Jira)
**Exit criteria**
- Acceptance criteria present
- Data classification tagged (PII/PCI/Internal/Public)
- Threat model tag (None/Light/Required)
- Dependencies listed
- Definition of Done applied

**Agent support**
- Story Readiness Agent flags missing info, proposes AC/test scenarios

### Gate 1 — Spec & Design Approval (Repo + Confluence)
**Exit criteria**
- SpecDD artifacts committed
- Confluence design summary posted (derived from specs)
- Architecture impacts identified
- Security posture noted (auth, logging, data boundaries)

**Approvers**
- Product + Tech Lead (+ Security if flagged)

### Gate 2 — Build Quality (PR)
**Exit criteria**
- Unit tests pass
- Lint/format/static checks pass
- SAST + dependency scan pass
- Coverage delta within policy

### Gate 3 — Acceptance & Evidence (CI + Playwright)
**Exit criteria**
- Acceptance suite green (API + UI where applicable)
- Evidence attached (screenshots/videos/logs)
- Flakes flagged (no silent healing without review)

### Gate 4 — Governance & Release Readiness
**Exit criteria**
- AI Production Check passes (if AI involved)
- Audit packet generated (traceability + evidence)
- Rollback plan present
- Release notes generated

**Only then:** merge + deploy (per existing change controls).

---

## 5. Agent suite

### 5.1 Minimum viable program (start here: 7 agents)
1. **Sprint Harvester** — Jira → sprint story set, clusters, risk flags
2. **Spec Synthesizer** — Jira → SpecDD artifacts + AC expansions
3. **Planner** — spec → branch/commit plan and impacted files
4. **Coder** — implements code changes and updates specs/docs
5. **Unit Test Agent** — TDD-first test creation and iteration
6. **E2E Agent** — Playwright (UI) + acceptance mapping
7. **Evidence & Release Agent** — Confluence updates + release notes + audit packet

### 5.2 Phase 2 additions
- **Security Agent** — advanced authz review, secure defaults, exception handling
- **Integration/Contract Agent** — contract tests, schema compatibility
- **Regression Sentinel** — test impact analysis and suite selection
- **Master Reviewer Agent** — PR “final boss” for consistency
- **AI Production Check Agent** — governance + reliability for AI features

---

## 6. AI Production Check (bank-grade control set)

Trigger if story labels include: `AI`, `LLM`, `RAG`, `Model`, `Embedding`.

**Checks**
- Secrets & key hygiene (no keys in repo; vault references only)
- Rate limiting & quotas (per-user/per-app; backoff; circuit breaker)
- AuthN/AuthZ (scope minimization; service identity; least privilege)
- Data boundaries (PII/PCI redaction; retrieval allowlists; no open web unless approved)
- Prompt injection controls (RAG): tool-call constraints, sanitization, policy checks
- Output safety: restricted data handling, citations where required, refusal behavior
- Observability: structured logs, correlation IDs, retention + redaction
- Evaluation harness: golden tests, adversarial probes, latency thresholds
- Change control: model pinning + upgrade approvals

**Output:** AI Readiness Report attached to PR and Confluence.

---

## 7. Repo + documentation structure (to avoid noisy artifacts)

Recommended structure:
```text
/specs/
  api/
  rules/
  nfr/
  ui/
/tests/
  unit/
  integration/
  acceptance/
/docs/
  adr/
  design/
/agents/
  agents.md
  copilot-instructions.md
  prompts/
```

**Rule:** keep docs thin, standardized, and traceable. Prefer structured artifacts + short summaries.

---

## 8. Templates (Jira + Confluence)
- Jira story template and labeling scheme: see `templates/jira_story_template.md`
- Confluence page templates: see `templates/confluence_templates.md`

---

## 9. 2-Day cadence (reference runbook)

### Day 1 (AM): Intake → Spec → Gate 1
- Agents pull sprint stories and generate spec + acceptance
- Confluence design summaries posted
- Humans approve Gate 1 asynchronously

### Day 1 (PM): Build → Gate 2
- Implementation + unit tests
- PRs opened, iterated until Gate 2 passes

### Day 2 (AM): Acceptance + evidence → Gate 3
- Acceptance suite runs (API/UI)
- Evidence captured and linked

### Day 2 (PM): Governance + release readiness → Gate 4
- AI checks (if applicable)
- Audit packet + release notes assembled
- Master review approval, merge, deploy

---

## 10. Staffing model (high-leverage pod)

A mature, well-tested codebase can often deliver with:
- 1 Product (fast decisions, story hygiene)
- 1 Tech Lead/Architect (patterns, design gate, risk ownership)
- 2–4 Engineers (reviewers/triagers; handle edge cases)
- 1 QA/Automation owner (acceptance suite & flake discipline)
- Security partner (part-time, policy-as-code + exceptions)
- DevEx/Platform (shared, CI templates + MCP/agent infrastructure)

**Key shift:** fewer people doing repetitive execution; more leverage in review, governance, and platform.

---

## Appendix A — Definitions
- **SpecDD:** Specifications first; structured specs are the source of truth.
- **TDD:** Tests first; implementation follows.
- **ADD:** Acceptance criteria are executable; acceptance is provable and auditable.
