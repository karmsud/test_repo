# Agent Prompt Pack (VS Code Copilot Agents + MCP)

> Store these as markdown files under `.github/prompts/` (or your bank-standard location) and expose them as slash commands.

**Conventions**
- Always include: sprint name or Jira JQL, repo name, branch naming convention, and target Confluence space/page.
- Every run must output:
  - Actions taken
  - Artifacts created/updated
  - Links (Jira keys, PR URLs, Confluence pages)
  - Gate status (0–4)
  - Risks/follow-ups

---

## /harvest_sprint
**Intent:** Pull sprint stories, cluster, flag risks, propose missing AC/tests.

**Prompt**
1. Query Jira via MCP for sprint: `<SPRINT_NAME>` (or JQL: `<JQL>`)
2. For each story:
   - Extract title, description, AC, labels/tags, dependencies, components
   - Flag missing Gate 0 requirements
3. Produce:
   - Sprint story table
   - Risk flags and which gate they affect
   - Recommended story splits (if too large)
   - Proposed AC and test intent for missing/weak stories
4. Post a Sprint Pack draft to Confluence using the Sprint Pack template.

---

## /generate_specs
**Intent:** Create SpecDD artifacts for each `ready:agent` story.

**Prompt**
1. For each story labeled `ready:agent`:
   - Generate structured specs (as applicable):
     - OpenAPI / JSON Schema
     - Rule decision tables
     - NFR YAML
     - Gherkin features for acceptance
2. Commit specs to `/specs/...` in a branch `spec/<SPRINT>/<JIRAKEY>`
3. Create/update Confluence Design Summary with links to spec files.

---

## /plan_implementation
**Intent:** Convert specs into a commit plan and file impact map.

**Prompt**
For story `<JIRAKEY>`:
- Read spec files in `/specs/...`
- Propose:
  - branch name
  - commit breakdown (3–8 commits)
  - impacted modules/files
  - risks + mitigations
Output the plan in PR-ready markdown.

---

## /tdd_unit_tests
**Intent:** Write failing unit tests first; ensure meaningful assertions.

**Prompt**
For story `<JIRAKEY>` on branch `<BRANCH>`:
- Create failing unit tests reflecting AC and edge cases
- Ensure negative cases and meaningful assertions
- Run tests; iterate until meaningful and passing with implementation

---

## /implement_story
**Intent:** Implement per spec and open PR (do not merge).

**Prompt**
- Sync to latest `main`
- Create branch `feat/<SPRINT>/<JIRAKEY>-<short>`
- Implement per SpecDD artifacts
- Update derived docs (short summaries only)
- Open PR with:
  - what/why/how
  - test plan + results
  - links to Jira + Confluence
- Do NOT merge.

---

## /acceptance_add_suite
**Intent:** Ensure ADD artifacts exist and are executable.

**Prompt**
- Convert AC into Gherkin in `/tests/acceptance/*.feature`
- Implement step bindings or API acceptance tests
- Ensure traceability: scenario ↔ Jira key
- Run the acceptance suite; report results

---

## /playwright_e2e
**Intent:** Generate/update Playwright tests for critical UI paths and capture evidence.

**Prompt**
- Use Playwright MCP to:
  - Launch app (local or test env)
  - For each acceptance scenario marked `ui`:
    - Generate/update Playwright test
    - Run tests; capture screenshots/videos/logs
- Flag flakiness explicitly; do not silently heal without reporting.

---

## /ai_production_check
**Intent:** Run bank-grade checks for AI/RAG stories.

**Prompt**
Validate:
- secrets exposure, unsafe logging, missing redaction
- rate limiting, timeouts, retries, circuit breakers
- auth scopes and least privilege
- RAG: retrieval allowlist, prompt injection controls, tool-call constraints
- evaluation: golden + adversarial prompts, latency thresholds
Output an AI Readiness Report to Confluence + PR.

---

## /evidence_and_release_pack
**Intent:** Compile audit packet and release notes.

**Prompt**
For sprint `<SPRINT_NAME>`:
- compile traceability matrix: Jira → commits → tests → evidence → approvals
- generate release notes + rollback plan + ops notes
- post to Confluence Sprint Pack page
