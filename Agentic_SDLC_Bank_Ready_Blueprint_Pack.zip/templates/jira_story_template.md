# Jira Story Template + Labeling Scheme (Agentic SDLC)

## A. Story Template (copy/paste)

### Title
`[Component] <Outcome-focused story title>`

### Problem / Outcome
- **Problem:**  
- **User/Business outcome:**  
- **Success measure:** (e.g., latency, defect reduction, adoption)

### Scope
- **In scope:**  
- **Out of scope:**  

### Acceptance Criteria (ADD-ready)
> Prefer Gherkin when possible.

**Option 1 — Bullets**
- AC1:
- AC2:
- AC3:

**Option 2 — Gherkin**
```gherkin
Feature: <Feature name>
  Scenario: <Happy path>
    Given ...
    When ...
    Then ...

  Scenario: <Negative/edge>
    Given ...
    When ...
    Then ...
```

### Data Classification & Privacy
- **Data classification:** PII / PCI / Internal / Public
- **PII/PCI fields impacted (if any):**
- **Logging & redaction requirements:**

### Security / Risk
- **Threat model:** None / Light / Required
- **AuthN/AuthZ changes:** Yes/No (describe)
- **New permissions/scopes:** (if applicable)
- **External connectivity/model providers:** (if applicable)

### Non-Functional Requirements (NFR)
- Latency budget:
- Timeout/retry policy:
- Rate limiting:
- Availability expectations:
- Observability (metrics, logs, traces):

### Test Intent (TDD + ADD)
- Unit tests:
- Integration/contract tests:
- Acceptance tests:
- E2E (Playwright) scenarios (if UI):

### Dependencies
- Systems:
- Teams:
- Config/feature flags:

### Rollback Plan
- Rollback mechanism:
- Data rollback needed? Yes/No
- Feature flag strategy:

---

## B. Labels / Tags (recommended)

### Work-type tags
- `work:ui`
- `work:api`
- `work:data`
- `work:integration`
- `work:infra`

### Risk tags
- `risk:auth`
- `risk:data-migration`
- `risk:payment-impact`
- `risk:customer-impact`
- `risk:compliance`

### Data tags
- `data:pii`
- `data:pci`
- `data:internal`
- `data:public`

### AI tags (triggers AI Production Check)
- `ai:llm`
- `ai:rag`
- `ai:embeddings`
- `ai:model-change`

### Readiness tags
- `ready:agent` (Gate 0 passed)
- `needs:ac`
- `needs:security-review`
- `needs:spec`

---

## C. Required Jira fields for Gate 0
- Acceptance criteria
- Data classification
- Threat model tag
- Test intent
- Rollback notes
