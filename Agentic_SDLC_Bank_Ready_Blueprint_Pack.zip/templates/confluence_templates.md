# Confluence Templates (Agentic SDLC)

## 1) Sprint Pack Page (auto-generated)
**Title:** `Sprint <Name/Number> — Delivery Pack`

### Summary
- Sprint goal:
- Release window:
- Risk posture (high-level):

### Story Table
| Jira Key | Title | Component | Risk Tags | Gate Status | PR Link |
|---|---|---|---|---|---|

### Specs & Design
- Spec index (repo paths):
- Design summaries (links):
- ADRs (if any):

### Test & Evidence
- Unit test summary:
- Integration/contract summary:
- Acceptance/E2E summary:
- Evidence pack links (reports, screenshots, logs):

### Release Notes
- Customer/user facing:
- Internal changes:
- Operational notes (monitoring/alerts):

### Rollback Plan
- Feature flags:
- Deployment rollback:
- Data rollback:

---

## 2) Design Summary Page (derived from SpecDD)
**Title:** `<Component> — Design Summary — <Jira Key/Epic>`

### Intent
- Outcome:
- Scope:

### Contracts (source of truth)
- API spec link:
- Rule tables link:
- UI flow specs link:
- NFR spec link:

### Architecture
- High-level flow:
- Data flow:
- Error handling and failure modes:
- Security boundaries:

### Observability
- Metrics:
- Logs (with redaction):
- Tracing:

### Open questions / decisions
- Decision log + owner + date:

---

## 3) AI Readiness Report (if AI-tagged)
**Title:** `AI Readiness — <Jira Key>`

### Model & Provider
- Model name/version:
- Hosting/provider:
- Change control reference:

### Data Boundaries
- Data classification:
- Retrieval sources allowlist:
- Redaction policy:

### Security Controls
- Secrets handling:
- Auth scopes:
- Tool-call constraints:

### Reliability Controls
- Rate limits:
- Timeouts/retries:
- Circuit breaker/fallback:

### Evaluation & Monitoring
- Golden tests summary:
- Adversarial tests summary:
- Latency budget and results:
- Drift monitoring triggers:

### Approval
- Product:
- Tech Lead:
- Security (if required):
- Date:
